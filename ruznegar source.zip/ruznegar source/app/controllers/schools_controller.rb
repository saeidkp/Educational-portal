class SchoolsController < ApplicationController
  load_and_authorize_resource
  before_action :set_school, only: [:show, :edit, :update, :destroy]
  before_filter { @top_tab = 'schools' }

  # GET /schools
  def index
    page = params[:page] || 0
    @schools = School.page(page).per(50)
  end

  # GET /schools/1
  def show
    @tab = params[:tab] || ''
    if @tab == 'users'
      @users = User.where(school_id: @school.id)
    end
  end

  # GET /schools/new
  def new
    @school = School.new
  end

  # GET /schools/1/edit
  def edit
  end

  # POST /schools
  def create
    @school = School.new(school_params)

    respond_to do |format|
      if @school.save
        format.html { redirect_to @school, notice: 'مدرسه با موفقیت ایجاد شد.' }
      else
        format.html { render action: 'new' }
      end
    end
  end

  # PATCH/PUT /schools/1
  def update
    respond_to do |format|
      if @school.update(school_params)
        format.html { redirect_to @school, notice: 'مدرسه با موفقیت به روز شد.' }
      else
        format.html { render action: 'edit' }
      end
    end
  end

  # DELETE /schools/1
  def destroy
    @school.destroy
    respond_to do |format|
      format.html { redirect_to schools_url }
    end
  end

private
  # Use callbacks to share common setup or constraints between actions.
  def set_school
    @school = School.find(params[:id])
  end

  # Never trust parameters from the scary internet, only allow the white list through.
  def school_params
    params.require(:school).permit(:name, :admin)
  end
end
