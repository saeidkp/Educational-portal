class PagesController < ApplicationController
  def index
    @news = if current_user.admin?
      News.order(created_at: :desc).limit(10)
    else
      News.where(school_id: [current_user.school_id, nil]).order(created_at: :desc).limit(10)
    end
  end

  def me
    @tab = params[:tab] || ''
    @user = current_user
    if @tab == 'courses'
      if @user.advisor?
        @courses = @user.group.courses
      elsif @user.student?
        @courses = @user.courses
      elsif @user.parent?
        @courses = @user.parent_of.courses
      elsif @user.teacher?
        @courses = @user.teachings
      end
    end
  end

  def settings
    if current_user.advisor?
      @group = Group.includes(:klasses).find current_user.group_id
      @klasses = @group.klasses
      render 'settings_advisor'
    elsif current_user.user_type >= APP_CONFIG['user_types']['manager']
      @groups = Group.includes(:klasses).where(school_id: @school.id)
      @klasses = @groups.collect(&:klasses).flatten
      render 'settings_manager'
    else
      redirect_to '/'
    end
  end

  def update_me
    if !current_user.student?
      valid_fields = ['name', 'self_phone', 'password', 'password_confirmation', 'username']
      user_params = params[:user].select{|f| valid_fields.include? f}
      current_user.update_attributes user_params
      if current_user.valid?
        redirect_to '/me'
      else
        redirect_to '/me?tab=edit'
      end
    else
      redirect_to '/me'
    end
  end

  def time
    @time = TopicTableTime.find(params[:id])
    if current_user.advisor?
      unless @time.topic_table.topic.klass.group_id == current_user.group_id
        raise CanCan::AccessDenied
      end
    elsif current_user.higher_than? 'advisor'
      unless @time.topic_table.topic.klass.group.school_id == current_user.school_id
        raise CanCan::AccessDenied
      end
    else
      raise CanCan::AccessDenied
    end
  end

  def edit_time
    @time = TopicTableTime.find(params[:id])
    if current_user.advisor?
      unless @time.topic_table.topic.klass.group_id == current_user.group_id
        raise CanCan::AccessDenied
      end
    elsif current_user.higher_than? 'advisor'
      unless @time.topic_table.topic.klass.group.school_id == current_user.school_id
        raise CanCan::AccessDenied
      end
    else
      raise CanCan::AccessDenied
    end
    valid_fields = [:minutes, :time_type]
    if @time.update params.select{|f| valid_fields.include? f}
      redirect_to topic_path @time.topic_table.topic
    else
      render action: 'new_time'
    end
  end

  def new_time
    if params[:table_id]
      @table = TopicTable.find params[:table_id]
    end
    if current_user.advisor?
      unless @table.topic.klass.group_id == current_user.group_id
        raise CanCan::AccessDenied
      end
    elsif current_user.higher_than? 'advisor'
      unless @table.topic.klass.group.school_id == current_user.school_id
        raise CanCan::AccessDenied
      end
    else
      raise CanCan::AccessDenied
    end
    @courses = @table.topic.klass.courses
    @time = TopicTableTime.new topic_table_id: @table.id
  end

  def create_time
    if params[:table_id]
      @table = TopicTable.find params[:table_id]
    end
    if current_user.advisor?
      unless @table.topic.klass.group_id == current_user.group_id
        raise CanCan::AccessDenied
      end
    elsif current_user.higher_than? 'advisor'
      unless @table.topic.klass.group.school_id == current_user.school_id
        raise CanCan::AccessDenied
      end
    else
      raise CanCan::AccessDenied
    end
    @courses = @table.topic.klass.courses
    valid_fields = ['minutes', 'time_type', 'course_id']
    @time = TopicTableTime.new params.select{|f| valid_fields.include? f}.merge(topic_table_id: @table.id)
    if @courses.collect(&:id).include? @time.course_id
      if @time.save
        redirect_to topic_path @table.topic
      else
        render action: 'new_time'
      end
    else
      render action: 'new_time'
    end
  end

  def destroy_time
    @time = TopicTableTime.find(params[:id])
    if current_user.advisor?
      unless @time.topic_table.topic.klass.group_id == current_user.group_id
        raise CanCan::AccessDenied
      end
    elsif current_user.higher_than? 'advisor'
      unless @time.topic_table.topic.klass.group.school_id == current_user.school_id
        raise CanCan::AccessDenied
      end
    else
      raise CanCan::AccessDenied
    end
    @topic = @time.topic_table.topic
    @time.destroy
    redirect_to @topic
  end

  def new_table
    @topic_id = params[:topic_id]
    if @topic_id
      @topic = Topic.find(@topic_id)
      if current_user.advisor?
        unless @topic.klass.group_id == current_user.group_id
          raise CanCan::AccessDenied
        end
      elsif current_user.higher_than? 'advisor'
        unless @topic.klass.group.school_id == current_user.school_id
          raise CanCan::AccessDenied
        end
      else
        raise CanCan::AccessDenied
      end
      @table = @topic.tables.build
    else
      redirect_to topics_path
    end
  end

  def create_table
    @topic_id = params[:topic_id]
    if @topic_id
      @topic = Topic.find(@topic_id)
      if current_user.advisor?
        unless @topic.klass.group_id == current_user.group_id
          raise CanCan::AccessDenied
        end
      elsif current_user.higher_than? 'advisor'
        unless @topic.klass.group.school_id == current_user.school_id
          raise CanCan::AccessDenied
        end
      else
        raise CanCan::AccessDenied
      end
      _params = {topic_id: @topic.id, user_ids: params[:user_ids] || []}
      @table = @topic.tables.build _params
      if @table.save
        redirect_to @topic
      else
        render action: 'new_table'
      end
    else
      redirect_to topics_path
    end
  end

  def destroy_table
    @table = TopicTable.find params[:id]
    @topic = Topic.includes(:users).find @table.topic_id
    return redirect_to @topic if @table.is_default
    if current_user.advisor?
      unless @topic.klass.group_id == current_user.group_id
        raise CanCan::AccessDenied
      end
    elsif current_user.higher_than? 'advisor'
      unless @topic.klass.group.school_id == current_user.school_id
        raise CanCan::AccessDenied
      end
    else
      raise CanCan::AccessDenied
    end
    @table.destroy
    redirect_to @topic
  end

  def edit_table
    @table = TopicTable.find params[:id]
    @topic = Topic.includes(:users).find @table.topic_id
    return redirect_to @topic if @table.is_default
    if current_user.advisor?
      unless @topic.klass.group_id == current_user.group_id
        raise CanCan::AccessDenied
      end
    elsif current_user.higher_than? 'advisor'
      unless @topic.klass.group.school_id == current_user.school_id
        raise CanCan::AccessDenied
      end
    else
      raise CanCan::AccessDenied
    end
  end

  def update_table
    @table = TopicTable.find params[:id]
    @topic = Topic.includes(:users).find @table.topic_id
    return redirect_to @topic if @table.is_default
    if current_user.advisor?
      unless @topic.klass.group_id == current_user.group_id
        raise CanCan::AccessDenied
      end
    elsif current_user.higher_than? 'advisor'
      unless @topic.klass.group.school_id == current_user.school_id
        raise CanCan::AccessDenied
      end
    else
      raise CanCan::AccessDenied
    end
    _params = {user_ids: params[:user_ids] || []}
    if @table.update _params
      redirect_to @topic
    else
      render action: 'edit_table'
    end
  end

end
