class ApplicationController < ActionController::Base
  # Prevent CSRF attacks by raising an exception.
  # For APIs, you may want to use :null_session instead.
  protect_from_forgery with: :exception

  before_filter do
    unless user_signed_in? or request.fullpath == new_user_session_path
      redirect_to new_user_session_path
    end
  end

  before_filter :configure_permitted_parameters, if: :devise_controller?

  before_filter do
    resource = controller_name.singularize.to_sym
    method = "#{resource}_params"
    params[resource] &&= send(method) if respond_to?(method, true)
  end

  before_filter do
    if controller_name == 'exams'
      if ['create', 'update'].include? params[:action]
        change_date request.params
      end
      # if params[:action] == 'points'
      #   puts ">> #{params[:exam][:points_attributes]}"
      #   puts ">> #{request.params[:exam][:points_attributes]}"
      #   params[:exam][:points_attributes] = request.params[:exam][:points_attributes]
      # end
    elsif controller_name == 'users' and ['create', 'update'].include? params[:action]
      change_date request.params
    end
  end

  before_action do
    if current_user
      if current_user.admin?
        if session[:school_id]
          @school = School.where(id: session[:school_id])
        end
        @school ||= School.first
      else
        @school = current_user.school
      end
    end
  end

  def respond_to_forbidden
    render 'pages/forbidden', layout: false,status: 403
  end

  def respond_to_not_found
    render 'pages/not_found', layout: true , status: 404
  end

  protected

  def configure_permitted_parameters
    devise_parameter_sanitizer.for(:sign_up) { |u| u.permit(:username, :password, :password_confirmation, :remember_me) }
    devise_parameter_sanitizer.for(:sign_in) { |u| u.permit(:username, :password, :remember_me) }
    devise_parameter_sanitizer.for(:account_update) { |u| u.permit(:username, :password, :password_confirmation, :current_password) }
  end

  rescue_from CanCan::AccessDenied do |exception|
    # In a proper way use respond_to_not_found (not for development)
    respond_to_forbidden
  end

  rescue_from ActiveRecord::RecordNotFound do |e|
    respond_to_not_found
  end

end
