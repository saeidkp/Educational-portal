class ExamsController < ApplicationController
  load_and_authorize_resource
  before_action :setup_exam_new, only: [:new, :create]
  before_action :setup_exam_edit, only: [:edit, :update]
  before_action :setup_exam, only: [:show, :destroy, :edit_points]
  
  def index
    page = params[:page] || 0
    if can? :manage, @course
      @exams = @course.exams.page(page).per(50)
    elsif can? :read, @course
      @exams = current_user.exams.where(course_id: @course.id).page(page).per(50)
    else
      return respond_to_forbidden
    end
  end

  def new
    @exam = @course.exams.build date: Time.now
  end

  def create
    @exam = @course.exams.build exam_params
    if @exam.save
      redirect_to exam_path(@exam)
      # render "show"
    else
      render "new"
    end
  end

  def show
    @points = Point.includes(:user).where(id: @exam.point_ids)
  end

  def update
    @exam.update_attributes exam_params
    if @exam.valid?
      render "show"
    else
      render "edit"
    end
  end

  def edit
  end

  def destroy
    if @exam.destroy
      redirect_to({controller: 'courses', action: 'show', course_id: @course.id})
    else
      redirect_to({controller: 'exams', action: 'show', id: @exam.id})
    end
  end

  def edit_points
  end

  def points
    _params = exam_params
    points_attributes = {}
    points = Point.includes(:user).where(exam_id: @exam.id).entries
    if params[:file]
      if params[:file].content_type == "text/csv"
        xls = Roo::CSV.new(params[:file].path)
      else
        xls = Roo::Spreadsheet.open(params[:file].path, extension: 'xlsx')
      end
      xls.to_a.each do |r|
        row = r.compact
        if row.count and row[0].to_i != 0
          points_attributes[row[0].to_i] = row[1]
        end
      end
      points.each do |point|
        unless points_attributes[point.user.username.to_i].nil?
          point.mark = points_attributes[point.user.username.to_i]
        end
      end
    else
      points_attributes = exam_params[:points_attributes]
      points_attributes.each do |i, point|
        ex_p = points.find{|p| p.id == point[:id].to_i}
        if ex_p and point[:mark]
          ex_p.mark = point[:mark]
        end
      end
    end
    ActiveRecord::Base.transaction do
      points.each(&:save)
      pts = points.pluck(:mark).compact
      if pts.length > 0
        @exam.update_attributes(average: pts.sum / pts.length, max: pts.max, min: pts.min)
      else
        @exam.update_attributes(average: nil, min: nil, max: nil)
      end
    end
    redirect_to controller: 'exams', action: 'show', id: @exam.id
  end

private
  
  def exam_params
    params.require(:exam).permit(:date, :course_id, user_ids: [], points_attributes: [:mark, :id])
  end

  def exam_date(hash)
    date_j = JalaliDate.new hash[:year].to_i, hash[:month].to_i, hash[:day].to_i
    date_g = date_j.to_g
    Time.new date_g.year, date_g.month, date_g.day, hash[:hour].to_i, hash[:minute].to_i
  end

  def change_date(hash)
    params[:exam][:date] = exam_date(hash[:exam]) if hash[:exam] and hash[:exam][:year]
    hash[:exam].delete(:year)
    hash[:exam].delete(:month)
    hash[:exam].delete(:day)
    hash[:exam].delete(:hour)
    hash[:exam].delete(:minute)
  end

  def setup_exam
    @exam = Exam.includes(:course).find params[:id]
    @course = @exam.course
  end

  def setup_exam_new
    course_id = params[:exam] ? params[:exam][:course_id] || params[:course_id] : params[:course_id]
    @course = Course.find course_id
  end

  def setup_exam_edit
    @exam = Exam.includes(:users, :course).find params[:id]
    @course = @exam.course
  end

end
