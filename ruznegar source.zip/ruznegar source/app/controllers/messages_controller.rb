class MessagesController < ApplicationController
  before_action :set_message, only: [:show, :destroy]

  # GET /messages
  def index
    @tab = params[:tab] || ''
    if @tab == 'sent'
      @messages = Message.where(from_id: current_user.id).page(params[:page] || 0).per(50)
    else
      @messages = current_user.messages.where(m_type: APP_CONFIG['message_type']['message']).limit(20).order(:created_at)
    end
    # current_user.update_attributes has_message: false
  end

  # GET /messages/1
  def show
  end

  # GET /messages/new
  def new
    @tab = params[:tab]
    if APP_CONFIG['message_type'][@tab.nil? ? 'message' : @tab].nil?
      return redirect_to controller: 'messages', action: 'new'
    end
    @multiple = !(current_user.student? || current_user.parent?)
    @users = User.where(school_id: current_user.school_id)
    @selected = []
    @message = Message.new
  end

  # POST /messages
  def create
    _params = message_params.merge(from_id: current_user.id)
    @message = Message.new _params
    unless (current_user.admin? or current_user.manager? or current_user.advisor?) and [0,1,2].include? _params[:m_type]
      _params[:m_type] = 0
    end
    @multiple = !(current_user.student? || current_user.parent?)
    @users = User.where(school_id: current_user.school_id)
    @selected = _params[:to] || params[:to]
    if @selected
      if @selected.is_a? Array
        if current_user.admin? or current_user.manager? or current_user.advisor?
          _to = @selected.collect(&:to_i)
        else
          flash[:alert] = "خطایی در ارسال پیش آمده است، لطفا دوباره تلاش کنید."
          return render action: 'new'
        end
      else
        _to = [@selected.to_i]
      end
      if current_user.manager?
        _to = User.where(school_id: current_user.school_id, id: _to).pluck(:id)
      end
      _params.delete :to
      _params[:user_ids] = _to
      if _params[:user_ids].length > 0
        Rails.logger.error ">> #{_params}"
        @message = Message.new(_params)
        if @message.save
          flash[:notice] = 'پیام ارسال شد.'
          redirect_to '/'
        else
          render action: 'new'
        end
      else
        flash[:alert] = "افراد دریاف‌کننده مشخص نشده است"
        render action: 'new'
      end
    else
      flash[:alert] = "افراد دریاف‌کننده مشخص نشده است"
      render action: 'new'
    end

  end

  # DELETE /messages/1
  def destroy
    @message.destroy
    redirect_to messages_url, notice: 'Message was successfully destroyed.'
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_message
      @message = Message.includes(:from).find(params[:id])
    end

    # Only allow a trusted parameter "white list" through.
    def message_params
      params.require(:message).permit(:content, :m_type, :to)
    end
end
