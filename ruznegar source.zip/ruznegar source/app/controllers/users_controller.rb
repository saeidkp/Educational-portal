class UsersController < ApplicationController
  load_and_authorize_resource
  before_filter { @top_tab = 'users' }
  before_action :setup_user, only: [:show, :destroy, :edit, :update]
  
  def index
    page = params[:page] || 0
    @user_type = params[:type]
    if current_user.admin?
      if @user_type
        if @user_type == 'other'
          @users = User.where.not(user_type: APP_CONFIG['user_types'][@user_type]).page(page).per(50)
        else
          @users = User.where(user_type: APP_CONFIG['user_types']['student']).page(page).per(50)
        end
      else
        @users = User.type_students.page(page).per(50)
      end
    elsif current_user.manager?
      if @user_type
        if @user_type == 'other'
          @users = User.where(school_id: current_user.school_id).where.not(user_type: APP_CONFIG['user_types']['student']).page(page).per(50)
        else
          @users = User.where(user_type: APP_CONFIG['user_types'][@user_type], school_id: current_user.school_id).page(page).per(50)
        end
      else
        @users = User.where(school_id: current_user.school_id).page(page).per(50)
      end
    elsif current_user.advisor?
      if @user_type
        if @user_type == 'other'
          @users = User.where.not(user_type: APP_CONFIG['user_types']['student'], group_id: current_user.group_id).page(page).per(50)
        elsif @user_type == 'teacher'
          courses = Course.includes(:teacher).where(id: current_user.group.course_ids)
          @users = courses.collect(&:teacher)
        elsif @user_type == 'student'
          @users = User.type_students.where(group_id: current_user.group_id).page(page).per(50)
        end
      else
        redirect_to users_path(type: 'student')
      end
    elsif current_user.student? or current_user.parent?
      if @user_type
        if @user_type == 'other'
          @users = User.where.not(user_type: APP_CONFIG['user_types']['student'], group_id: current_user.group_id).page(page).per(50)
        elsif @user_type == 'teacher'
          courses = Course.includes(:teacher).where(id: current_user.course_ids)
          @users = courses.collect(&:teacher)
        elsif @user_type == 'student'
          @users = User.type_students.where(group_id: current_user.group_id).page(page).per(50)
        end
      else
        redirect_to users_path(type: 'student')
      end
    elsif current_user.teacher?
      if @user_type
        if @user_type == 'student'
          @users = User.type_students.where(id: current_user.teachings.pluck(:user_ids).flatten.compact).page(page).per(50)
        end
      else
        redirect_to users_path(type: 'student')
      end
    end
  end

  def show
    @message = Message.new
    @tab = params[:tab] || ''
    # SEVER: POINT ZERO
    if @user.student?
      if ['courses', 'score', 'message', ''].include?(@tab)
        if ['courses', 'score'].include? @tab
          unless current_user.admin? or (current_user.manager? and current_user.school_id == @user.school_id) or (current_user.advisor? and current_user.group_id == @user.group_id)
            redirect_to controller: 'users', action: 'show'
          end
        end
      else
        redirect_to controller: 'users', action: 'show'
      end
    elsif @tab != ''
      redirect_to controller: 'users', action: 'show'
    end
  end

  def new
    if current_user.admin?
    else
      @user = User.new(school_id: current_user.school_id)
    end
  end

  def create
    @user = User.new(user_params)
    if @user.save
      redirect_to @user
    else
      render "new"
    end
  end

  def edit
  end

  def update
    @user.update_attributes user_params
    if @user.valid?
      redirect_to @user
    else
      render "edit"
    end
  end

  def destroy
    @user.destroy
    redirect_to 'index'
  end

private
  def setup_user
    @user = User.includes(:school, :courses).find(params[:id])
    @school = @user.school
  end

  def user_params
    _ret = params.require(:user).permit(:name, :email, :username, :avatar, :self_phone, :home_phone, :father_name, 
                                        :father_phone, :father_email, :mother_name, :mother_phone, :mother_email, :birthday)
    if current_user.student?
      _ret.delete :username
    end
    _ret
  end

  def change_date(hash)
    date_g = JalaliDate.new(hash[:user][:birth_year].to_i, hash[:user][:birth_month].to_i, hash[:user][:birth_day].to_i).to_g
    birthday = DateTime.new date_g.year, date_g.month, date_g.day
    params[:user][:birthday] = birthday
    hash[:user].delete(:birth_year)
    hash[:user].delete(:birth_month)
    hash[:user].delete(:birth_day)
  end
end
