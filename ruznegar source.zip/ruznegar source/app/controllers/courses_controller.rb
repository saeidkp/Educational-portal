class CoursesController < ApplicationController
  load_and_authorize_resource
  before_filter { @top_tab = 'courses' }
  before_action :setup_course, only: [:show, :destroy, :edit, :update]

  def index
    page = params[:page] || 0
    @user_type = current_user.user_type
    case @user_type
    when APP_CONFIG['user_types']['manager'],APP_CONFIG['user_types']['admin']
      if params[:group_id]
        @groups = @school.groups.includes(:klasses).entries
        @group = @groups.find{|g| g.id == params[:group_id].to_i}
        @group ||= @groups.first
        @klasses = @group.klasses
        if params[:klass_id]
          @klass = @group.klasses.to_a.find{|k| k.id == params[:klass_id].to_i}
        end
        @klass ||= @group.klasses.first
      else
        @groups = @school.groups.includes(:klasses).entries
        @group = @groups.first
        @klasses = @group.klasses
        @klass = @klasses.first
      end
      unless @klass
        flash[:notice] = "#{I18n.t('class')}#{I18n.t('there_is_no')}"
        return redirect_to controller: 'klasses', action: 'new', group_id: @group.id
      end
      @klass_id = @klass.id
      @group_id = @group.id
      @courses = @klass.courses.page(page).per(50)
    when APP_CONFIG['user_types']['advisor']
      @klasses = current_user.group.klasses.includes(:courses)
      @klass = if params[:klass_id]
        @klasses.find{|k| k.id == params[:klass_id].to_i}
      else
        @klasses.first
      end
      @courses = @klass.courses.page(page).per(50)
    when APP_CONFIG['user_types']['teacher']
      @courses = Course.where(teacher_id: current_user.id).page(page).per(50)
    else
      @courses = current_user.courses.page(page).per(50)
    end
  end

  def new
    @klass_id ||= params[:klass_id]
    if @klass_id
      @klass = Klass.includes(:group).find(@klass_id)
      if @klass.group.school_id == @school.id
        @course = @klass.courses.build
        @users = User.type_students.where(klass_id: @klass_id)
      else
        redirect_to courses_path
      end
    else
      flash[:error] = "خطای رخ داده است!"
      redirect_to courses_path
    end
  end

  def create
    @klass_id ||= params[:klass_id]
    if @klass_id
      @klass = Klass.includes(:group).find(@klass_id)
      if @klass.group.school_id == @school.id
        @course = @klass.courses.build(course_params)
      else
        redirect_to courses_path
      end
    else
      flash[:error] = "خطای رخ داده است!"
      redirect_to courses_path
    end
    if @course.save
      if ['1', 'yes', 'on', 'true', true, 't'].include? params[:copy]
        @course.klass.group.copy_course @course
      end
      redirect_to @course, notice: 'درس با موفقیت ایجاد شد.'
    else
      render 'new', params: {group_id: @group_id}
    end
  end

  def show
    @tab = params[:tab] || ''
    if @tab == 'exams'
      @exams = @course.exams.page(params[:page] || 0).per(50)
    end
  end

  def update
    if @course.update(course_params_update)
      redirect_to @course, notice: 'درس با موفقیت به روز شد.'
    else
      render action: 'edit'
    end
  end

  def edit
    @group = Group.includes(:users).find(@course.group_id)
    @users = @group.users.where(user_type: APP_CONFIG['user_types']['student'])
  end

  def destroy
    if @course.destroy
      flash[:success] = "درس #{@course.name} حذف شد!"
      redirect_to courses_url
    else
      redirect_to courses_url
    end
  end

private
  def setup_course
    @course = Course.includes(:users, :exams).find(params[:id])
  end

  def course_params
    params.require(:course).permit(:teacher_id, :group_id, :name, user_ids: [])
  end

  def course_params_update
    params.require(:course).permit(:teacher_id, :name, user_ids: [])
  end

end
