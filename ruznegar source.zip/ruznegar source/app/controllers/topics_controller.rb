class TopicsController < ApplicationController
  before_action :set_topic, only: [:edit, :update, :destroy]
  before_action{ @top_tab = 'topics' }

  # GET /topics
  def index
    @topics = if current_user.advisor?
      Topic.where(klass_id: current_user.group.klass_ids)
    elsif current_user.higher_than?('advisor')
      klasses = Klass.includes(:topics).where(group_id: @school.group_ids)
      klasses.collect(&:topics).flatten
    end
  end

  # GET /topics/1
  def show
    @topic = Topic.includes(:users, :tables).find(params[:id])
    if current_user.advisor?
      return redirect_to topics_path unless @topic.klass.group_id == current_user.group_id
    elsif current_user.higher_than?('advisor')
      return redirect_to topics_path unless @topic.klass.group.school_id == @school.id
    else
      return redirect_to '/'
    end
  end

  # GET /topics/new
  def new
    if current_user.advisor?
      @klasses = current_user.group.klasses
    elsif current_user.higher_than?('advisor')
      @groups = Group.includes(:klasses).where(school_id: @school.id)
    else
      return redirect_to '/'
    end
    @topic = Topic.new
  end

  # GET /topics/1/edit
  def edit
  end

  # POST /topics
  def create
    _params = topic_create_params
    @topic = Topic.new(_params)
    if current_user.advisor?
      @klasses = current_user.group.klasses
      unless @klasses.collect(&:id).include? @topic.klass_id
        return render action: 'new'
      end
    elsif current_user.higher_than?('advisor')
      @groups = Group.includes(:klasses).where(school_id: @school.id)
      unless @groups.collect(&:klasses).flatten.collect(&:id).include? @topic.klass_id
        return render action: 'new'
      end
    else
      return redirect_to '/'
    end
    if @topic.save
      if ['1', 'yes', 'on', 'true', true, 't'].include? params[:copy]
        @topic.copy_to_other_klasses
      end
      redirect_to @topic
    else
      render action: 'new'
    end
  end

  # PATCH/PUT /topics/1
  def update
    if @topic.update(topic_params)
      redirect_to @topic
    else
      render action: 'edit'
    end
  end

  # DELETE /topics/1
  def destroy
    @topic.destroy
    redirect_to topics_url
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_topic
      @topic = Topic.find(params[:id])
    end

    # Only allow a trusted parameter "white list" through.
    def topic_create_params
      params.require(:topic).permit(:name, :klass_id)
    end

    def topic_params
      params.require(:topic).permit(:name, :klass_id, user_ids: [])
    end
end
