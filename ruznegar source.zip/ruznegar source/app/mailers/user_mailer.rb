class UserMailer < ActionMailer::Base
  default from: "from@kit-o.org"

  def send_message(from, user, content)
    @from = from
    @user = user
    @content = content
    mail to: @user.email, subject: "سیستم مدیریت مدرسه"
  end
end
