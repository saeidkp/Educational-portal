class User < ActiveRecord::Base
  # Include default devise modules. Others available are:
  # :token_authenticatable, :confirmable,
  # :lockable, :timeoutable and :omniauthable
  devise :database_authenticatable, :rememberable, :trackable, :authentication_keys => [:username] #,
         # :recoverable, :validatable, :registerable

  belongs_to :school # For all except admin
  # has_many :groups # For teachers
  has_many :teachings, class_name: 'Course', foreign_key: :teacher_id # For teacher
  belongs_to :parent_of, class_name: 'User', foreign_key: :parent_id # For parent
  has_one :parent, class_name: 'User', foreign_key: :parent_of_id # For Student
  belongs_to :group # For student, advisor
  belongs_to :klass # For student
  belongs_to :topic # For student
  belongs_to :topic_table # For student
  has_and_belongs_to_many :courses # For student
  has_many :exams, through: :points # For student
  has_many :points # For student

  has_and_belongs_to_many :messages

  validate :freeze_user_type, on: :update
  validate :username_change, on: :update

  after_create {
    if student?
      p = User.type_parents.create  username: "p#{username}",
                                    password: home_phone[-4..-1],
                                    name: "ولی دانش‌آموز #{name}",
                                    email: father_email,
                                    self_phone: father_phone,
                                    parent_of_id: id,
                                    school_id: school_id,
                                    group_id: group_id
      update_attributes parent_id: p.id
    end
  }

  has_attached_file :avatar,
    url: '/static/users/:id/:style.png',
    path: ':rails_root/public/static/users/:id/:style.png',
    styles: {
      big: ["128x128>", :png],
      thumb: ["64x64>", :png]
    },
    default_url: "/static/users/0/:style.png",
    storage: :filesystem,
    default_style: :thumb

  scope :type_students, ->{ where(user_type: APP_CONFIG['user_types']['student']) } # user_type of 1 means student
  scope :type_parents, ->{ where(user_type: APP_CONFIG['user_types']['parent']) } # user_type of 2 means student
  scope :type_teachers, ->{ where(user_type: APP_CONFIG['user_types']['teacher']) } # user_type of 3 means student
  scope :type_advisors, ->{ where(user_type: APP_CONFIG['user_types']['advisor']) } # user_type of 4 means student
  scope :type_managers, ->{ where(user_type: APP_CONFIG['user_types']['manager']) } # user_type of 5 means staff
  scope :type_admins, ->{ where(user_type: APP_CONFIG['user_types']['admin']) } # user_type of 6 means admin

  %w(student parent teacher advisor manager admin).each do |type|
    define_method("#{type}?") { user_type == APP_CONFIG['user_types'][type] }
  end

  def higher_than?(type)
    user_type > APP_CONFIG['user_types'][type].to_i
  end

  def self.find_first_by_auth_conditions(warden_conditions)
    conditions = warden_conditions.dup
    puts ">> #{conditions}"
    if login = conditions.delete(:login)
      where(conditions).where(["lower(username) = :value OR lower(email) = :value", { :value => login.downcase }]).first
    else
      where(conditions).first
    end
  end

private
  def freeze_user_type
    errors.add(:user_type, "Cannot be changed") if self.user_type_changed?
  end

  def username_change
    if self.username_changed?
      if self.username_changable
        self.username_changable = false
      else
        errors.add(:username, "Username can't be changed")
      end
    end
  end
end
