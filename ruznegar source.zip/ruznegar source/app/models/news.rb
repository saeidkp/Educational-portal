class News < ActiveRecord::Base
  scope :site_news, -> {where school_id: nil}
  belongs_to :school
  belongs_to :writer, class_name: 'User'
end
