class Group < ActiveRecord::Base
  belongs_to :school
  belongs_to :advisor, class_name: 'User'
  has_many :users
  has_many :klasses
  after_create do
    ActiveRecord::Base.transaction do
      user = User.type_advisors.create(school_id: school_id, group_id: id, name: "مشاور #{name} #{school.name}", username: "advisor#{id}", password: "advisor#{id}")
      update advisor_id: user.id
    end
  end

  def copy_course(course)
    ActiveRecord::Base.transaction do
      klasses.to_a.reject{|k| k.id == course.klass_id}.each{|klass|
        klass.courses.create name: course.name, teacher_id: course.teacher_id
      }
    end
  end
end
