class Exam < ActiveRecord::Base
  has_many :points
  has_many :users, through: :points
  belongs_to :course

  # accepts_nested_attributes_for :users
  accepts_nested_attributes_for :points, reject_if: proc{ |attributes| attributes['mark'].blank? }

  def year; jalali.year; end
  def month; jalali.month; end
  def day; jalali.day; end
  def hour; date ? date.hour : Time.now.hour; end
  def minute; date ? date.min : Time.now.min; end

  def jalali
    date ? JalaliDate.new(date) : JalaliDate.today
  end
end
