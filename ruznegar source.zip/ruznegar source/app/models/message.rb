class Message < ActiveRecord::Base
  belongs_to :from, class_name: "User"
  has_and_belongs_to_many :users

  before_create do
    self.m_type ||= 0
  end

  after_create do
    if sms?
      # Send message via sms
    elsif email?
      users.each do |user|
        UserMailer.send_message(from, user, content).deliver
      end
    else
      users.each{|u|
        u.update_attributes has_message: true
      }
    end
  end

  %w(sms message email).each do |type|
    define_method("#{type}?") { m_type == APP_CONFIG['message_type'][type] }
  end

  validates :m_type, inclusion: {in: [0, 1, 2]}

end
