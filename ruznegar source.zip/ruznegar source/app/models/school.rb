class School < ActiveRecord::Base
  belongs_to :admin, class_name: 'User', foreign_key: :admin_id
  # has_many :students, class_name: 'User', foreign_key: :school_id
  def students; User.type_students.where(school_id: id); end
  has_many :groups
  has_many :news
  after_create {
    update_attributes admin: User.type_managers.create(school_id: id, name: "مدیر #{name}", username: "school#{id}", password: "school#{id}")
    groups.create(['پایه‌ی اول', 'پایه‌ی دوم', 'پایه‌ی سوم', 'پایه‌ی چهارم'].map{|p| {name: p}})
  }

  def teachers
    User.where(user_type: APP_CONFIG['user_types']['teacher'], school_id: id)
  end

  def students
    User.where(user_type: APP_CONFIG['user_types']['student'], school_id: id)
  end

  def student_ids
    User.where(user_type: APP_CONFIG['user_types']['student'], school_id: id).pluck(:id)
  end

  def teacher_ids
    User.where(user_type: APP_CONFIG['user_types']['teacher'], school_id: id).pluck(:id)
  end
end
