class Point < ActiveRecord::Base
  # properties :
  # 
  #   mark => Float
  #   user_id => user
  #   exam_id => exam
  belongs_to :user
  belongs_to :exam
end
