class TopicTable < ActiveRecord::Base
  has_many :times, class_name: 'TopicTableTime'
  has_many :users
  belongs_to :topic
end
