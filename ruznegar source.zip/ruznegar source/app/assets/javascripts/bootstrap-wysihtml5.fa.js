/**
 * Persian translation for bootstrap-wysihtml5
 */
(function($){
    $.fn.wysihtml5.locale["fa-IR"] = {
        font_styles: {
              normal: "متن معمولی",
              h1: "سربرگ نوع ۱",
              h2: "سربرگ نوع ۲",
              h3: "سربرگ نوع ۳",
              h4: "سربرگ نوع ۴",
              h5: "سربرگ نوع ۵",
              h6: "سربرگ نوع ۶"
        },
        emphasis: {
              bold: "ضخیم",
              italic: "کج",
              underline: "زیرخط"
        },
        lists: {
              unordered: "لیست معمولی",
              ordered: "لیست شماره‌دار",
              outdent: "بیرون آمدگی",
              indent: "تورفتگی"
        },
        link: {
              insert: "افزودن لینک",
              cancel: "بی‌خیال",
              target: "لینک در صفحه‌ی جدید"
        },
        image: {
              insert: "افزودن تصویر",
              cancel: "پی‌خیال"
        },
        html: {
            edit: "ویرایشگر پیشرفته"
        },

        colours: {
            black: "سیاه",
            silver: "نقره‌ای",
            gray: "خاکستری",
            maroon: "قهوه‌ای",
            red: "قرمز",
            purple: "بنفش",
            green: "سبز",
            olive: "زیتونی",
            navy: "آبی تیره",
            blue: "آبی",
            orange: "نارنجی"
        }
    };
}(jQuery));
