#! /usr/bin/env bash

cp wysihtml5-0.3.0.js _editor.js
cat bootstrap-wysihtml5.js >> _editor.js
cat bootstrap-wysihtml5.fa.js >> _editor.js

uglifyjs _editor.js -o editor.js -pcm

rm _editor.js
