// This is a manifest file that'll be compiled into application.js, which will include all the files
// listed below.
//
// Any JavaScript/Coffee file within this directory, lib/assets/javascripts, vendor/assets/javascripts,
// or vendor/assets/javascripts of plugins, if any, can be referenced here using a relative path.
//
// It's not advisable to add code directly here, but if you do, it'll appear at the bottom of the
// compiled file.
//
// Read Sprockets README (https://github.com/sstephenson/sprockets#sprockets-directives) for details
// about supported directives.
//
//= require jquery
//= require jquery_ujs
// require turbolinks
// require bootstrap
//= require bootstrap/transition
//= require bootstrap/dropdown
//= require bootstrap/tooltip
//= require bootstrap/popover
//= require bootstrap/alert
//= require bootstrap/modal
//= require chart
//  require bootstrap-datepicker
//  require bootstrap-datepicker.fa
//= require users
//= require select2
//= require select2_locale_fa
//= require exams
//  require_tree .

$(function() {
  $('select.has-select2').select2();
  var uniRegex = /[^\u0000-\u00ff]/;
  var hasUnicode = function(str) {
    return uniRegex.test(str);
  };
  var getSmsLength = function(str) {
    return str.replace(/([{}\[\]\\|\^~€])/g, "\\$1").replace(/\n/g, "--").length;
  };
  $('.sms-text').keyup(function(e) {
    var $this = $(this);
    var val = $this.val();
    var html = "";
    var isu = hasUnicode(val);
    var length = isu ? val.length : getSmsLength(val), count = 0, remaining = 0, factor = isu ? 70 : 160;
    if (length > factor) factor = isu ? 67 : 153;
    count = Math.ceil(length/factor);
    remaining = count * factor - length;
    html = '<b class="text-danger">' + count + "/1</b> - " + length + ' - <b class="text-success">' + remaining + '</b>';
    $this.parent().find('.help-block').html(html);
  });
  $('.pannel-toggle').click(function(e) {
    e.preventDefault();
    var $this = $(this);
    $this.closest('.panel').find('table,.list-group,.panel-body').toggle();
    $this.find('i').toggleClass('glyphicon-chevron-up').toggleClass('glyphicon-chevron-down');
    return false;
  });
});