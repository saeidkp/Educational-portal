module ApplicationHelper
  def persian_numbers(str)
    str ? str.unpack('U*').map{ |e| (0..9).to_a.include?(e-48) ? e + 1728 : e }.pack('U*') : ''
  end

  def persian_date(date)
    date ? persian_numbers(JalaliDate.new(date).format("%A %d %b %Y - %H:%m")) : ''
  end

  def persian_months
    {
      'فروردین'   =>  1,
      'اردیبهشت'  =>  2,
      'خرداد'     =>  3,
      'تیر'       =>  4,
      'مرداد'     =>  5,
      'شهریور'    =>  6,
      'مهر'       =>  7,
      'آبان'      =>  8,
      'آذر'       =>  9,
      'دی'        => 10,
      'بهمن'      => 11,
      'اسفند'     => 12 
    }
  end

  def persian_days
    (1..31).to_a.map{|i| {persian_numbers(i.to_s) => i.to_s}}.reduce({}, :merge)
  end

  def persian_years
    today = JalaliDate.today
    y = today.year
    if today.month < 7
      { persian_numbers(y.to_s) => y.to_s}
    else
      { persian_numbers(y.to_s) => y.to_s, persian_numbers((y+1).to_s) => (y+1).to_s}
    end
  end

  def flash_class(level)
    case level
        when :notice then "alert alert-info"
        when :success then "alert alert-success"
        when :error then "alert alert-danger"
        when :alert then "alert alert-warning"
    end
  end

  def title(page_title)
    content_for :title, "مدیر مدرسه :‌ "+page_title.to_s
  end

  def score_state_on_exam(point, exam)
    avg = exam.average
    if avg.nil?
      return "<s>بدون نمره</s>"
    else
      mark = point.mark
      min = exam.min
      max = exam.max
      if mark.nil?
        return '<b class="text-danger">غایب</b>'
      end
      if mark > avg
        if mark - avg >= (max - avg)/2
          return '<b class="text-success">عالی</b>'
        else
          return '<b class="text-primary">خوب</b>' 
        end
      else
        if avg - mark <= (avg - min)/2
          return '<b class="text-danger">ضعیف</b>'
        else
          return '<b class="text-warning">متوسط</b>' 
        end
      end
    end
  end

  def there_is_no(key)
    I18n.t(key)+I18n.t('there_is_no')
  end
end
