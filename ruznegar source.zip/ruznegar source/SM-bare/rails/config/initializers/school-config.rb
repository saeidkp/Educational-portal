APP_CONFIG = YAML.load_file(Rails.root.join('config','yaml', 'config.yaml') )

SMS = {
  url: 'http://www.niksms.com/sendByPost.php',
  user: 'khalina',
  pass: '743d2361588d238bff996e3687811d62',
  num: '9830002530025300'
}

Bank = {
  namespace: 'http://interfaces.core.sw.bps.com/',
  wsdl: 'https://bpm.shaparak.ir/pgwchannel/services/pgw?wsdl',
  payUrl: 'https://bpm.shaparak.ir/pgwchannel/startpay.mellatU',
  userName: 'irysc',
  userPassword: 'ir99ys',
  terminalId: 909350,
  text: 'پرداخت مبلغ جهت شارژ اکانت سیستم مدیریت مدرسه.',
  callBackUrl: 'http://www.ruznegar.com/checkOrder'
}
