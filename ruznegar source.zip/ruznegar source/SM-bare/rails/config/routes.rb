SchoolManager::Application.routes.draw do
  resources :advisories, only: [:index, :new, :create, :destroy]

  resources :polls do
    member do
      get 'new_option' => 'polls#new_option'
      post 'new_option' => 'polls#create_option'
      get 'options/:option_id' => 'polls#edit_option'
      post 'options/:option_id' => 'polls#save_option'
      delete 'options/:option_id' => 'polls#delete_option'
      post 'vote' => 'polls#vote'
    end
  end

  resources :reports do
    member do
      post 'points/:course_id' => 'reports#points'
      get 'points/:course_id' => 'reports#edit_points'
      delete 'points/:course_id' => 'reports#delete_course'
      get 'new_course' => 'reports#add_course_form'
      post 'new_course' => 'reports#add_course'
    end
  end

  get '/printable_report' => 'pages#printable_report'
  get '/printable_course' => 'pages#printable_report_course'
  get '/printable_activity' => 'pages#printable_activity'
  get '/printable_objection' => 'pages#printable_objection'

  get '/user_reports' => 'pages#show_reports'

  get '/student_reports' => 'pages#student_reports'

  resources :topics

  resources :messages, only: [:index, :new, :create, :destroy] do
    get 'sent' => 'messages#index_sent', on: :collection
  end

  resources :klasses, only: [:new, :create, :edit, :update, :destroy]

  resources :news

  resources :schools

  devise_for :users
  resources :users do
    collection do
      post 'import' => 'users#import'
    end
    member do
      post 'lock' => 'users#lock'
      post 'unlock' => 'users#unlock'
    end
  end
  resources :courses# do
  #   resources :exams do
  #     patch 'points' => 'exams#points' ,on: :member
  #     get 'points' => 'exams#edit_points' ,on: :member
  #   end
  # end
  get 'me' => 'pages#me'
  post 'me' => 'pages#update_me'
  get 'settings' => 'pages#settings'
  post 'settings' => 'pages#save_settings'
  resources :exams do
    member do
      patch 'points' => 'exams#points'
      get 'points' => 'exams#edit_points'
      get 'excel' => 'exams#points_excel'
    end
  end

  get 'time/:id' => 'pages#time'
  post 'time/:id' => 'pages#edit_time'
  delete 'time/:id' => 'pages#destroy_time'
  get 'time' => 'pages#new_time'
  post 'time' => 'pages#create_time'

  get 'table' => 'pages#new_table'
  post 'table' => 'pages#create_table'
  get 'table/:id' => 'pages#edit_table'
  post 'table/:id' => 'pages#update_table'
  delete 'table/:id' => 'pages#destroy_table'

  get 'weekly_table' => 'pages#weekly_table'
  get 'weekly_table/edit' => 'pages#edit_weekly_table'
  post 'weekly_table/edit' => 'pages#save_weekly_table'

  get 'calendar' => 'pages#calendar'
  get 'calendar/edit' => 'pages#calendar_edit'
  post 'calendar/edit' => 'pages#calendar_edit_save'

  get 'readings' => 'pages#readings'
  post 'readings' => 'pages#save_readings'

  delete 'event/:id' => 'pages#destroy_event'
  
  get 'grades' => 'pages#grades'
  post 'grades' => 'pages#objection'

  get 'stats' => 'pages#stats'

  get 'balance' => 'pages#balance'
  post 'balance' => 'pages#add_balance'

  get 'add_balance' => 'users#add_balance'
  post 'add_balance' => 'users#add_balance_post'

  post 'update_password' => 'pages#update_password'

  post 'checkOrder' => 'pages#checkOrder'

  get 'time_table' => 'pages#time_table'
  post 'time_table' => 'pages#time_table_post'

  root "pages#index"

  get 'test' => 'pages#test'
  # root "index#home"
end
