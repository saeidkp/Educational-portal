class UserMailer < ActionMailer::Base
  default from: "Ruznegar <info@ruznegar.com>"

  def send_message(from, emails, content)
    @from = from
    @content = content
    from_email = from.username+(from.school_id ? '-'+from.school_id.to_s : '')+'@ruznegar.com'
    mail from: "#{from.name} - Ruznegar <#{from_email}>", bcc: emails, subject: "سیستم مدیریت مدرسه"
  end
end
