class Report < ActiveRecord::Base
  has_many :report_courses, dependent: :destroy
  belongs_to :klass
  has_many :report_users, dependent: :destroy
  has_many :users, ->{uniq}, through: :report_users
  has_many :objections, dependent: :destroy

  after_create do
    report_users.create klass.users.map{|u| {user: u} }
  end

  def get_object report_user, report_course
    objections.where(report_user: report_user, report_course: report_course).first
  end

  def can_object(report_user)
    objection and created_at+objection_limit.days>Date.today and (objection_courses == 0 or report_user.objections.count < objection_courses)
  end

  def regenerate_points
    ActiveRecord::Base.transaction do
      r_users = report_users.includes(:user)
      r_courses = report_courses.includes(:course, :points)
      r_points = r_courses.collect(&:points).flatten
      exams = Exam.includes(:points).where(course_id: r_courses.collect(&:course_id))
      r_courses.each do |report_course|
        points_hash = Hash[r_users.collect(&:user).collect{|user| [user.id, {q_sum: 0, q_count: 0, t_sum: 0, t_count: 0}]}]
        exams.select{|exam| exam.course_id == report_course.course_id && exam.date.past? && exam.date > start_date}.each do |exam|
          exam.points.each do |point|
            if points_hash[point.user_id]
              if exam.quiz?
                points_hash[point.user_id][:q_sum] += (point.mark || 0)*1.0/exam.range
                points_hash[point.user_id][:q_count] += 1
              else
                points_hash[point.user_id][:t_sum] += (point.mark || 0)*1.0/exam.range
                points_hash[point.user_id][:t_count] += 1
              end
            end
          end
        end
        points_hash.each do |user_id, point_hash|
          point = r_points.find{|r| r.user_id == user_id && r.report_course_id == report_course.id}
          unless point
            point = report_course.points.build user_id: user_id, bare_point: 0
          end
          base_mark = (point_hash[:q_count] > 0 ? report_course.exam_quiz_part*point_hash[:q_sum]/point_hash[:q_count] : 0) +
                      (point_hash[:t_count] > 0 ? report_course.exam_homework_part*point_hash[:t_sum]/point_hash[:t_count] : 0) +
                      (max_grade - report_course.exam_quiz_part - report_course.exam_homework_part)*(point.bare_point || 0)
          point.mark = base_mark / max_grade
          point.save
        end
        marks = report_course.points.collect(&:mark).compact.sort.reverse
        if marks.count > 0
          report_course.max = marks.max
          report_course.min = marks.min
          report_course.average = marks.sum/marks.count
          report_course.save
          report_course.points.each do |point|
            if point.mark
              rank = marks.index(point.mark) || marks.index(marks.find{|m| point.mark < m})
              point.update rank: 1+rank
            else
              logger.debug ">> #{point.bare_point}"
            end
          end
        end
      end
    end
    ActiveRecord::Base.transaction do
      r_courses = report_courses.includes(:course, :points)
      r_points = r_courses.collect(&:points).flatten
      report_users.each do |r_user|
        user_points = r_points.select{|p| p.user_id == r_user.user_id}
        marks_sum = 0
        marks_count = 0
        user_points.each{|p|
          marks_sum += p.report_course.multiplier.to_i * p.mark.to_i
          marks_count += p.report_course.multiplier.to_i
        }
        if marks_count != 0
          r_user.average = marks_sum / marks_count
        else
          r_user.average = nil
        end
        r_user.save
      end
      averages = report_users.collect(&:average).compact.sort.reverse
      report_users.each do |r_user|
        r_user.update rank: 1+averages.index(r_user.average)
      end
    end
  end
end
