class ClassTableTime < ActiveRecord::Base
  # attributes:
  #   day (day_of_week) : integer
  #   hour (hour of day) : integer (0<x<4)
  #   opt_text (optional text at the end of fucking shits) : string
  #   tak_zang (2 course in a time) : boolean
  #   course_id (course) : integer (belongs_to)
  #   second_course_id (course) : integer (belongs_to)
  belongs_to :course
  belongs_to :second_course, class_name: 'Course'
end
