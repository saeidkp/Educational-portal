require "uri"
require "net/http"

class Message < ActiveRecord::Base
  belongs_to :from, class_name: "User"
  has_and_belongs_to_many :users
  has_many :delivery_statuses, class_name: 'SmsStatus', dependent: :destroy
  validates :users, length: {minimum: 1, message: 'لیست کاربران نمیتواند خالی باشد'}
  validates :content, presence: {message: 'محتوای پیام نمیتواند خالی باشد.'}
  validate :sms_balance
  do_not_validate_attachment_file_type :file

  has_attached_file :file,
    url: '/static/files/:hash/:filename',
    path: ':rails_root/public/static/files/:hash/:filename',
    hash_secret: "12aa2f37ad44ee0fa2207d18e47da1d2ede49ab58ef3d1981918b89765be1d0d",
    storage: :filesystem

  validates_attachment_size :file, less_than: 10.megabytes, unless: Proc.new{|i| i.file_file_name.blank?}

  before_create do
    self.m_type ||= 0
  end

  after_create do
    if email?
      UserMailer.send_message(from, emails, content).deliver
    else
      users.each{|u|
        u.update_attributes has_message: true
      }
    end
  end

  %w(sms message email).each do |type|
    define_method("#{type}?") { m_type == APP_CONFIG['message_type'][type] }
  end

  validates :m_type, inclusion: {in: [0, 1, 2]}

  def nums
    @nums ||= begin
      _nums = users.collect(&:self_phone)
      _nums += users.select{|u| u.parent?}.collect do |u|
        u.parent_of && [u.parent_of.mother_phone, u.parent_of.father_phone]
      end.compact.flatten
      _nums.reject{|num| num.blank?}.uniq
    end
  end

  def emails
    @emails ||= begin
      _emails = users.collect(&:email)
      _emails += users.select{|u| u.parent?}.collect do |u|
        u.parent_of && [u.parent_of.mother_email, u.parent_of.father_email]
      end.compact.flatten
      _emails.reject{|email| email.blank?}.uniq
    end
  end

  def send_sms
    params = {
      login: SMS[:user],
      pass: SMS[:pass],
      isMd5: true,
      recNums: nums.join(','),
      msgBody: content,
      senderNum: SMS[:num],
      send: 1
    }
    request = Net::HTTP.post_form(URI.parse(SMS[:url]), params)
    if request.body =~ /Error/
      self.failed = true
      Rails.logger.error "SMS Error: #{request.body}"
      return false
    end
    save
    from.update balance: from.balance - msg_count*Settings.first.sms_price
    ActiveRecord::Base.transaction do
      request.body.split(',').each do |d|
        SmsStatus.create message_id: self.id, deliver: d
      end
    end
    return true
  end

  def msg_count
    message_length = content.gsub(/([{}\[\]\\|\^~€])/, "\\$1").gsub(/\n/, "--").length
    isu = !(/[^\u0000-\u00ff]/ =~ content).nil?
    factor = isu ? 70 : 160
    if message_length > factor
      factor = isu ? 67 : 153
    end
    (message_length/factor.to_f).ceil*nums.count*(isu ? 1 : 2)
  end

  def sms_balance
    if sms?
      message_count = msg_count
      if from.balance < message_count*Settings.first.sms_price
        errors.add(:content, "اعتبار برای ارسال پیامک کم است")
      end
    end
  end

end
