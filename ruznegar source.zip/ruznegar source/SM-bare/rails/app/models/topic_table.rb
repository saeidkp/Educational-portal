class TopicTable < ActiveRecord::Base
  has_many :times, class_name: 'TopicTableTime', dependent: :destroy
  has_many :users
  belongs_to :topic
end
