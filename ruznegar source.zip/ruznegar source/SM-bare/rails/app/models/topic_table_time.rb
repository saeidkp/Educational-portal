class TopicTableTime < ActiveRecord::Base
  # key minutes: :integer
  # key time_type: :integer
  belongs_to :topic_table
  belongs_to :course
  validates_presence_of :minutes, message: "مدت زمان نمی‌تواند خالی باشد"
end
