class TopicWeeklyTableTime < ActiveRecord::Base
  # Attributes
  #     dow: integer (day of week)
  #     duration: float, hours in on time
  belongs_to :topic_weekly, class_name: 'TopicWeeklyTable'
end
