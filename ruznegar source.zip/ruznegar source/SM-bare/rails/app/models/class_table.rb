class ClassTable < ActiveRecord::Base
  has_many :class_table_times, dependent: :destroy
  belongs_to :klass
  after_create do
    ActiveRecord::Base.transaction do
      (0..5).each do |day|
        (0..4).each do |hour|
          class_table_times.create day: day, hour: hour
        end
      end
    end
  end
end
