class Poll < ActiveRecord::Base
  has_many :poll_options, dependent: :destroy
  has_many :poll_votes
  belongs_to :school
  belongs_to :group

  scope :student_only, ->{ where(poll_type: APP_CONFIG['poll_type']['student_only']) }
  scope :parent_only, ->{ where(poll_type: APP_CONFIG['poll_type']['parent_only']) }
  scope :all_users, ->{ where(poll_type: APP_CONFIG['poll_type']['all_users']) }

  def self.for_parent(user)
    where(
      poll_type: [APP_CONFIG['poll_type']['parent_only'], APP_CONFIG['poll_type']['all_users']],
      school_id: user.school_id,
      group_id: [nil, user.group_id]
    ).where('"polls"."end_date" > ? OR "polls"."end_date" IS NULL', Date.today)
  end

  def self.for_student(user)
    where(
      poll_type: [APP_CONFIG['poll_type']['student_only'], APP_CONFIG['poll_type']['all_users']],
      school_id: user.school_id,
      group_id: [nil, user.group_id]
    ).where('"polls"."end_date" > ? OR "polls"."end_date" IS NULL', Date.today)
  end

  default_scope { where(poll_type: APP_CONFIG['poll_type']['student_only']) }
end
