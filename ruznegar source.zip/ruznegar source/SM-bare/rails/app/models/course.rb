class Course < ActiveRecord::Base
  # properties
  # 
  #    name => String
  has_many :exams, dependent: :destroy
  has_and_belongs_to_many :users

  belongs_to :klass
  
  belongs_to :teacher, class_name: 'User'#, foreign_key: :teacher_id

  delegate :group, to: :klass, allow_nil: false

  validates_presence_of :klass, on: :create, message: "can't be blank"

end
