class ReportPoint < ActiveRecord::Base
  belongs_to :user
  belongs_to :report_course
  delegate :report, to: :report_course, allow_nil: false

  validates_uniqueness_of :user_id, scope: :report_course_id
end
