class Topic < ActiveRecord::Base
  # key name: :string
  belongs_to :klass
  has_many :tables, class_name: 'TopicTable', dependent: :destroy
  has_many :users
  has_one :weekly_table, class_name: 'TopicWeeklyTable', dependent: :destroy
  after_create do
    tables.create is_default: true
    TopicWeeklyTable.create topic_id: id
  end

  def copy_to_other_klasses
    group = Group.includes(:klasses).where(id: klass.group_id).first
    ActiveRecord::Base.transaction do
      group.klasses.each do |klass|
        klass.topics.create name: name
      end
    end
  end

  def default_table
    tables.includes(:times).where(is_default: true).first
  end
end
