class Klass < ActiveRecord::Base
  # key name: :string
  has_many :users
  has_many :topics, dependent: :destroy
  has_many :courses, dependent: :destroy
  has_many :reports
  belongs_to :group
  # def weekly_table
  #   ClassTable.where(klass_id: id)
  # end
  has_one :weekly_table, class_name: ClassTable, dependent: :destroy
  validates_presence_of :name, message: "نام نمی‌تواند خالی باشد"
  validates_presence_of :group, message: "بدون گروه"
  
  after_create do
    ClassTable.create klass_id: self.id
  end

  def copy_from(another_klass)
    ActiveRecord::Base.transaction do
      another_klass.courses.each do |course|
        courses.create name: course.name, teacher_id: course.teacher_id
      end
    end
    another_topics = another_klass.topics
    self_courses = courses.entries
    another_topics.each do |another_topic| 
      topic = topics.create name: another_topic.name
      ActiveRecord::Base.transaction do
        times = another_topic.default_table.times
        if times.length > 0
          topic.default_table.times.create times.map{ |time|
            {
              minutes: time.minutes,
              time_type: time.time_type,
              course_id: self_courses.find{|c| c.name == time.course.name}.id
            }
          }
        end
      end
    end
  end
end
