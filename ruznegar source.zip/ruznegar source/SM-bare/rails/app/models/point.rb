class Point < ActiveRecord::Base
  # properties :
  # 
  #   mark => Float
  #   user_id => user
  #   exam_id => exam
  belongs_to :user
  belongs_to :exam
  validates_uniqueness_of :user_id, scope: :exam_id
end
