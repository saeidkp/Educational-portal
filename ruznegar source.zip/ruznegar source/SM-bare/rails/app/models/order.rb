class Order < ActiveRecord::Base
  belongs_to :user

  scope :completed, ->{ where(completed: true) }
  scope :incomplete, ->{ where(completed: false) }

  def request
    client = Savon.client(wsdl: Bank[:wsdl], namespace: Bank[:namespace])
    parameters = {
      terminalId: Bank[:terminalId],
      userName: Bank[:userName],
      userPassword: Bank[:userPassword],
      orderId: self.id,
      amount: self.amount,
      localDate: DateTime.now.strftime('%Y%m%d'),
      localTime: DateTime.now.strftime('%H%I%S'),
      additionalData: Bank[:text],
      payerId: '0',
      callBackUrl: Bank[:callBackUrl]
    }
    response = client.call(:bp_pay_request, message: parameters)
    body = response.body[:bp_pay_request_response]
    if body
      responseReturn = body[:return].split(',')
      if responseReturn[0] == '0'
        self.update refId: responseReturn[1]
      end
    end
    body
  end
end
