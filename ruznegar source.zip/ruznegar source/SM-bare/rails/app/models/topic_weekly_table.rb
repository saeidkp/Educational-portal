class TopicWeeklyTable < ActiveRecord::Base
  has_many :times, class_name: 'TopicWeeklyTableTime', dependent: :destroy, foreign_key: :topic_weekly_id
  belongs_to :topic
  after_create do
    ActiveRecord::Base.transaction do
      TopicWeeklyTableTime.create (0..6).map{|i| {topic_weekly: self, dow: i, hours: 4} }
    end
  end
end
