class Exam < ActiveRecord::Base
  has_many :points, dependent: :destroy
  has_many :users, ->{uniq}, through: :points
  belongs_to :course

  # accepts_nested_attributes_for :users
  accepts_nested_attributes_for :points, reject_if: proc{ |attributes| attributes['mark'].blank? }

  def year; jalali.year; end
  def month; jalali.month; end
  def day; jalali.day; end
  def hour; date ? date.hour : Time.now.hour; end
  def minute; date ? date.min : Time.now.min; end

  def jalali
    date ? JalaliDate.new(date) : JalaliDate.today
  end

  def quiz?
    exam_type == 0
  end

  def regenarate_ranks
    pts = points.collect(&:mark).compact.sort
    if pts.length > 0
      update_attributes(average: pts.sum / pts.length, max: pts.max, min: pts.min)
    else
      update_attributes(average: nil, min: nil, max: nil)
    end
    points.each{|pt| pt.rank = pt.mark ? pts.index(pt.mark)+1 : nil}
    points.each(&:save)
  end
end
