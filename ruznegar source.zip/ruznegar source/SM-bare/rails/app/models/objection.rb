class Objection < ActiveRecord::Base
  belongs_to :report
  belongs_to :report_user
  belongs_to :report_course
end
