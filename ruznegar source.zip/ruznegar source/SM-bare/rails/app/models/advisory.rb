class Advisory < ActiveRecord::Base
  belongs_to :user
  belongs_to :advisor, class_name: 'User'
end
