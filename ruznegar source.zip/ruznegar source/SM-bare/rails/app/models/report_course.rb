class ReportCourse < ActiveRecord::Base
  belongs_to :report
  belongs_to :course
  has_many :points, class_name: "ReportPoint", dependent: :destroy

  before_create do
    self.course_name = course.name
  end

  validates_uniqueness_of :report_id, scope: :course_id

  validates :course, presence: true
  validates :report, presence: true
end
