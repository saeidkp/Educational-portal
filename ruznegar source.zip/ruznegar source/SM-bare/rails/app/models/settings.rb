class Settings < ActiveRecord::Base
  # Attributes:
  #   sms_price: integer
end
