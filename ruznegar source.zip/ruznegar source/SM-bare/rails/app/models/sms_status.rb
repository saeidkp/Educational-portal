class SmsStatus < ActiveRecord::Base
  belongs_to :message
end
