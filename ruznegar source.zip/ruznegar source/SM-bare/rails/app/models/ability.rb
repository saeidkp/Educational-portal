class Ability
  include CanCan::Ability

  def initialize(user)
    if user
      case user.user_type
      when APP_CONFIG['user_types']['admin'] # One ring to rule them all!
        # Can do every fucking action they desired to!
        can :manage, :all

      when APP_CONFIG['user_types']['manager'] # School manager
        # Can edit and view their own school
        can [:read, :update], School, admin_id: user.id
        can :manage, Course do |course|
          if course.klass.nil? or course.klass.group.nil?
            true
          else
            course.klass.group.school_id == user.school_id
          end
        end
        can :manage, Klass do |klass|
          if klass.group.nil?
            true
          else
            klass.group.school_id == user.school_id
          end
        end
        can :manage, Topic do |topic|
          if topic.klass.nil?
            true
          else
            topic.klass.group.school_id == user.school_id
          end
        end

        can :manage, News do |news|
          user.school_id == news.school_id
        end

        can :read, Exam do |exam|
          exam.course.klass.group.school_id == user.school_id
        end

        # Can manage users in scope of school
        can :manage, User do |other_user|
          if other_user.school.nil?
            true
          else
            other_user.school_id == user.school_id
          end
        end

        can :manage, Report do |report|
          if report.klass.nil?
            true
          else
            report.klass.group.school_id == user.school_id
          end
        end

        can :manage, Poll do |poll|
          not poll.persisted? or poll.school_id == user.school_id
        end

      when APP_CONFIG['user_types']['advisor'] # Group manager
        # Can read school they joined
        can [:read], School, id: user.school_id

        # Can read and update group they're assigned as advisor of
        can [:read, :update], Group, advisor_id: user.id

        # Can manage everything inside it's group
        can :manage, Klass do |klass|
          if klass.group.nil?
            true
          else
            klass.group_id == user.group_id
          end
        end
        can :manage, Course do |course|
          if course.klass.nil?
            true
          else
            course.klass.group.school_id == user.school_id
          end
        end
        can :manage, Topic do |topic|
          if topic.klass.nil?
            true
          else
            topic.klass.group_id == user.group_id
          end
        end
        can :manage, Exam do |exam|
          if exam.course.nil?
            true
          else
            exam.course.klass.group_id == user.group_id
          end
        end

        can :manage, Report do |report|
          if report.klass.nil?
            true
          else
            report.klass.group_id == user.group_id
          end
        end

        can [:read, :update], User do |other_user|
          other_user.group_id == user.group_id
        end

        can :manage, Poll do |poll|
          not poll.persisted? or poll.group_id == user.group_id
        end

        can :manage, Advisory do |adv|
          not adv.id or adv.advisor_id == user.id
        end

      when APP_CONFIG['user_types']['teacher'] # Course manager (just can see points and set homeworks!)
        can :read, Course, teacher_id: user.id
        can :read, Exam do |exam|
          user.teaching_ids.include? exam.course_id 
        end
        can :read, User do |other_user|
          (other_user.course_ids & user.teaching_ids).count > 0
        end

      when APP_CONFIG['user_types']['parent'] # That's a parent, everybody knows what they do!
        can :read, News do |news|
          user.school_id == news.school_id
        end
        can :read, Course do |course|
          course.klass.group_id == user.parent_of.group_id
        end
        can :read, Point
        can [:read, :update], User, id: user.parent_of_id
        can :read, Exam do |exam|
          exam.course.klass_id == user.parent_of.klass_id
        end
      when APP_CONFIG['user_types']['student'] # hmm, sorry!
        can :read, News do |news|
          user.school_id == news.school_id
        end
        can :read, User do |other_user|
          user.id == other_user.id
        end
        can :read, Course do |course|
          user.course_ids.include? course.id
        end
        can :read, Exam do |exam|
          exam.course.klass_id == user.klass_id
        end
        can :read, Point do |point|
          user.point_ids.include? point.id
        end
      end
    end
  end
end
