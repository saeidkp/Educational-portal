class User < ActiveRecord::Base
  # Include default devise modules. Others available are:
  # :token_authenticatable, :confirmable,
  # :lockable, :timeoutable and :omniauthable
  devise :database_authenticatable, :rememberable, :lockable, :trackable, :recoverable, :authentication_keys => [:username] #,
         # :validatable, :registerable

  attr_accessor :generated_password
  def active_for_authentication?
    #remember to call the super
    #then put our own check to determine "active" state using 
    #our own "is_active" column
    super and self.is_active?
  end

  belongs_to :school # For all except admin
  # has_many :groups # For teachers
  has_many :teachings, class_name: 'Course', foreign_key: :teacher_id # For teacher
  belongs_to :parent_of, class_name: 'User' # For parent
  has_one :parent, class_name: 'User', dependent: :destroy, foreign_key: :parent_of_id # For Student
  belongs_to :group # For student, advisor
  belongs_to :klass # For student
  belongs_to :topic # For student
  belongs_to :topic_table # For student
  has_and_belongs_to_many :courses # For student
  has_many :points, dependent: :destroy # For student
  has_many :exams, ->{uniq}, through: :points # For student
  has_many :readings, dependent: :destroy # For student
  has_many :advisories, foreign_key: :advisor_id, dependent: :destroy # For student
  has_many :report_users, dependent: :destroy
  has_many :reports, ->{uniq}, through: :report_users

  has_and_belongs_to_many :messages

  validate :freeze_user_type, on: :update
  validate :username_change, on: :update
  validates :username, presence: {message: "نام کاربری الزامی‌ست"}, length: {minimum: 4, message: "نام کاربری باید حداقل ۴ حرف باشد"}, format: {with: /[-a-z0-9]+/, message: 'نام کاربری باید فقط حرف عدد یا خط تیره باشد.'}, uniqueness: { message: 'این نام کاربری قبلا انتخاب شده است' }
  validates :name, presence: {message: "نام الزامی‌ست"}

  after_create do
    if self.student?
      parent_password = if home_phone.length > 4
        home_phone[-4..-1]
      else
        username[0..3]
      end
      if self.password.blank?
        self.password = self.generated_password = parent_password
      end
      p = User.type_parents.create  username: "p#{username}",
                                    password: parent_password,
                                    name: "ولی #{name}",
                                    email: father_email,
                                    self_phone: father_phone,
                                    parent_of_id: self.id,
                                    school_id: school_id,
                                    group_id: group_id
      update_attributes parent_id: p.id
    end
  end

  after_destroy do
    if self.student?
      parent.destroy if parent
    end
    if self.parent?
      parent_of.destroy if parent
    end
  end

  has_attached_file :avatar,
    url: '/static/users/:hash/:style.png',
    path: ':rails_root/public/static/users/:hash/:style.png',
    hash_secret: "12aa2f37ad44ee0fa2207d18e47da1d2ede49ab58ef3d1981918b89765be1d0d",
    styles: {
      original: {
        geometry: '256x256#',
        format: :png,
        quality: 80
      },
      medium: {
        geometry: '128x128#',
        format: :png,
        quality: 70
      },
      thumb: {
        geometry: '64x64#',
        format: :png,
        quality: 50
      },
    },
    default_url: "/static/users/0/:style.png",
    storage: :filesystem,
    default_style: :thumb

  validates_attachment_content_type :avatar, :content_type => ["image/jpg", "image/jpeg", "image/png"]
  validates_attachment_size :avatar, less_than: 1.megabytes, unless: Proc.new{|i| i.avatar_file_name.blank?}

  scope :type_students, ->{ where(user_type: APP_CONFIG['user_types']['student']) } # user_type of 1 means student
  scope :type_parents, ->{ where(user_type: APP_CONFIG['user_types']['parent']) } # user_type of 2 means student
  scope :type_teachers, ->{ where(user_type: APP_CONFIG['user_types']['teacher']) } # user_type of 3 means student
  scope :type_advisors, ->{ where(user_type: APP_CONFIG['user_types']['advisor']) } # user_type of 4 means student
  scope :type_managers, ->{ where(user_type: APP_CONFIG['user_types']['manager']) } # user_type of 5 means staff
  scope :type_admins, ->{ where(user_type: APP_CONFIG['user_types']['admin']) } # user_type of 6 means admin

  %w(student parent teacher advisor manager admin).each do |type|
    define_method("#{type}?") { user_type == APP_CONFIG['user_types'][type] }
  end

  def higher_than?(type)
    user_type > APP_CONFIG['user_types'][type].to_i
  end

  def self.find_first_by_auth_conditions(warden_conditions)
    conditions = warden_conditions.dup
    puts ">> #{conditions}"
    if login = conditions.delete(:login)
      where(conditions).where(["lower(username) = :value OR lower(email) = :value", { :value => login.downcase }]).first
    else
      where(conditions).first
    end
  end

  def check_activity
    activity = Activity.where(user_id: id).last
    if activity
      activity.check_activity
    else
      Activity.create user_id: id, time: DateTime.now, duration: 0
    end
  end

private
  def freeze_user_type
    errors.add(:user_type, "Cannot be changed") if self.user_type_changed?
  end

  def username_change
    if self.username_changed?
      if self.username_changable
        self.username_changable = false
      else
        errors.add(:username, "نام کاربری قابل فقط یک بار میتواند تغییر کند")
      end
    end
  end
end
