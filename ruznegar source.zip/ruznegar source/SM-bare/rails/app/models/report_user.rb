class ReportUser < ActiveRecord::Base
  belongs_to :user
  belongs_to :report
  has_many :objections

  validates_uniqueness_of :user_id, scope: :report_id
end
