class News < ActiveRecord::Base
  scope :site_news, -> {where school_id: nil}
  belongs_to :school
  belongs_to :writer, class_name: 'User'
  validates :title, presence: {message: 'محتوای خبر نمیتواند خالی باشد.'}
  validates :content, presence: {message: 'عنوان خبر نمیتواند خالی باشد.'}
end
