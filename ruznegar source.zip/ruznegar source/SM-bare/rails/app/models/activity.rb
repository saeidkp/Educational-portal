class Activity < ActiveRecord::Base
  belongs_to :user

  def check_activity
    if time+duration.seconds > Time.now-2.minutes
      update duration: Time.now-time
    else
      Activity.create user_id: user_id, time: DateTime.now, duration: 0
    end
  end
end
