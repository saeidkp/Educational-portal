class AdvisoriesController < ApplicationController
  load_and_authorize_resource

  # GET /advisories
  def index
    today = JalaliDate.today
    if params[:date]
      date = JalaliDate.new(Date.parse(params[:date]))
    else
      date = today
    end
    @date = JalaliDate.new(date.year, date.month, 1)
    @prev_date = JalaliDate.new(@date.month == 1 ? @date.year - 1 : @date.year, @date.month != 1 ? @date.month - 1 : 12, 1).to_g
    @next_date = JalaliDate.new(@date.month == 12 ? @date.year + 1 : @date.year, @date.month != 12 ? @date.month + 1 : 1, 1).to_g
    @advisories = current_user.advisories.includes(:user).where(date: @date.to_g..@next_date-1.days)
    if params[:view] and params[:view]
      @view = params[:view]
    end
    if @view == 'user'
      @users = current_user.group.users.type_students
    end
  rescue ArgumentError
    redirect_to advisories_path
  end

  # GET /advisories/new
  def new
    @date = Date.parse(params[:date])
    if @date < Date.today
      redirect_to advisories_path
    end
    @advisory = current_user.advisories.build
    @users = current_user.group.users.type_students
  rescue ArgumentError
    redirect_to advisories_path
  end

  # POST /advisories
  def create
    _params = advisory_params
    @date = Date.parse(_params[:date])
    if @date < Date.today
      redirect_to advisories_path
    end
    @advisory = current_user.advisories.create(_params)
    redirect_to advisories_path
  end

  # DELETE /advisories/1
  def destroy
    @advisory = Advisory.find(params[:id])
    @advisory.destroy
    redirect_to advisories_url, notice: 'Advisory was successfully destroyed.'
  end

  private
    # Only allow a trusted parameter "white list" through.
    def advisory_params
      params.require(:advisory).permit(:user_id, :date, :description)
    end
end
