class PollsController < ApplicationController
  load_and_authorize_resource
  skip_authorize_resource only: [:vote]
  before_action :set_poll, only: [:show, :edit, :update, :destroy, :new_option, :create_option, :delete_option, :edit_option, :save_option, :vote]

  # GET /polls
  def index
    @polls = @school.polls
    if current_user.advisor?
      @polls = @polls.where(group_id: current_user.group_id)
    end
  end

  # GET /polls/1
  def show
    @poll_options = @poll.poll_options.includes(:poll_votes).to_a
    @users = User.where id: @poll_options.collect(&:poll_votes).flatten.collect(&:user_id)
  end

  def new_option
  end

  def create_option
    name = params[:name]
    if name
      @poll.poll_options.create name: name
    else
      render 'new_option'
    end
    redirect_to @poll
  end

  def edit_option
    set_option
  end

  def save_option
    set_option
    name = params[:name]
    if name
      @option.update name: name
    else
      render 'edit_option'
    end
    redirect_to @poll
  end

  def delete_option
    set_option
    @option.destroy
    redirect_to @poll
  end

  def vote
    value = params[:value]
    if not PollVote.where(user_id: current_user.id, poll_id: @poll.id).any?
      option = @poll.poll_options.where(id: value).first
      if option
        option.poll_votes.create user_id: current_user.id, poll_id: @poll.id
      end
    end
    redirect_to '/'
  end

  # GET /polls/new
  def new
    @poll = Poll.new
  end

  # GET /polls/1/edit
  def edit
  end

  # POST /polls
  def create
    @poll = Poll.new(poll_create_params)
    if current_user.advisor?
      @poll.group_id = current_user.group_id
    end
    @poll.school_id = @school.id
    if @poll.save
      redirect_to @poll
    else
      render action: 'new'
    end
  end

  # PATCH/PUT /polls/1
  def update
    if @poll.update(poll_params)
      redirect_to @poll
    else
      render action: 'edit'
    end
  end

  # DELETE /polls/1
  def destroy
    @poll.destroy
    redirect_to polls_url
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_poll
      @poll = Poll.find(params[:id])
    end

    def setup_end_date
      if params[:year] and params[:month] and params[:day]
        date_j = JalaliDate.new params[:year].to_i, params[:month].to_i, params[:day].to_i
        date_g = date_j.to_g
        date = Date.new date_g.year, date_g.month, date_g.day
        params[:poll][:end_date] = date
      end
    rescue ArgumentError
    end

    # Only allow a trusted parameter "white list" through.
    def poll_params
      setup_end_date
      params.require(:poll).permit(:title, :end_date, :visible)
    end

    def poll_create_params
      setup_end_date
      params.require(:poll).permit(:title, :group_id, :poll_type, :end_date, :visible)
    end

    def set_option
      @option = @poll.poll_options.find(params[:option_id])
    end
end
