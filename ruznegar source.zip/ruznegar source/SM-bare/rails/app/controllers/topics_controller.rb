class TopicsController < ApplicationController
  load_and_authorize_resource
  before_action :set_topic, only: [:edit, :update, :destroy]
  before_action{ @top_tab = 'topics' }

  # GET /topics
  def index
    @view = params[:view] || 'user'
    if @view == 'topic'
      @topics = if current_user.advisor?
        Topic.where(klass_id: current_user.group.klass_ids)
      elsif current_user.higher_than?('advisor')
        klasses = Klass.includes(:topics).where(group_id: @school.group_ids)
        klasses.collect(&:topics).flatten
      end
    else
      @users = if current_user.advisor?
        current_user.group.users.type_students.entries
      elsif current_user.higher_than?('advisor')
        @school.users.type_students.entries
      end
      if params[:user]
        @user = @users.find{|u| u.id == params[:user].to_i}
      end
      @user = @users.first unless @user
      if @user
        @topic = @user.topic
        @table = @user.topic_table
        @table = @topic.default_table if not @table and @topic
      end
    end
  end

  # GET /topics/1
  def show
    @topic = Topic.includes(:users, :tables).find(params[:id])
    if current_user.advisor?
      return redirect_to topics_path unless @topic.klass.group_id == current_user.group_id
    elsif current_user.higher_than?('advisor')
      return redirect_to topics_path unless @topic.klass.group.school_id == @school.id
    else
      return redirect_to '/'
    end
  end

  # GET /topics/new
  def new
    if params[:user]
      @user_ids = [params[:user].to_i]
    end
    if current_user.advisor?
      @klasses = current_user.group.klasses
      @user_ids = @user_ids & current_user.group.users.type_students.pluck(:id) if @user_ids
    elsif current_user.higher_than?('advisor')
      @groups = Group.includes(:klasses).where(school_id: @school.id)
      @user_ids = @user_ids & @school.users.type_students.pluck(:id) if @user_ids
    else
      return redirect_to '/'
    end
    if @user_ids and @user_ids.count > 0
      @klass_id = User.find(@user_ids[0]).klass_id
      @user = User.find @user_ids[0]
    else
      @user_ids = nil
    end
    @topic = Topic.new
  end

  # GET /topics/1/edit
  def edit
  end

  # POST /topics
  def create
    _params = topic_params_create
    if params[:user]
      @user_ids = [params[:user].to_i]
    end
    @topic = Topic.new(_params)
    if current_user.advisor?
      @klasses = current_user.group.klasses
      unless @klasses.collect(&:id).include? @topic.klass_id
        return render action: 'new'
      end
    elsif current_user.higher_than?('advisor')
      @groups = Group.includes(:klasses).where(school_id: @school.id)
      unless @groups.collect(&:klasses).flatten.collect(&:id).include? @topic.klass_id
        return render action: 'new'
      end
    else
      return redirect_to '/'
    end
    if @user_ids
      @user_ids = @topic.klass.user_ids & @user_ids
      if @user_ids.count > 0
        @topic.user_ids = @user_ids
      else
        @user_ids = nil
      end
    end
    if @topic.save
      if ['1', 'yes', 'on', 'true', true, 't'].include? params[:copy]
        @topic.copy_to_other_klasses
      end
      if @user_ids
        return redirect_to topics_url(user: @user_ids[0])
      else
        redirect_to @topic
      end
    else
      if @user_ids
        return redirect_to topics_url(user: @user_ids[0])
      else
        render action: 'new'
      end
    end
  end

  # PATCH/PUT /topics/1
  def update
    _params = topic_params
    _params[:user_ids] &= @topic.klass.user_ids.collect(&:to_s)
    if @topic.update(_params)
      if params[:table]
        times = @topic.weekly_table.times.entries
        ActiveRecord::Base.transaction { 
          params[:table].each do |dow, hours|
            if hours.to_f >= 0
              time = times.find{|time| time.dow == dow.to_i}
              if time
                time.update hours: hours.to_f
              end
            end
          end
        }
      end
      redirect_to @topic
    else
      render action: 'edit'
    end
  end

  # DELETE /topics/1
  def destroy
    @topic.destroy
    redirect_to topics_url
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_topic
      @topic = Topic.find(params[:id])
    end

    # Only allow a trusted parameter "white list" through.
    def topic_params_create
      params.require(:topic).permit(:name, :klass_id)
    end

    def topic_params
      params.require(:topic).permit(:name, :klass_id, user_ids: [])
    end
end
