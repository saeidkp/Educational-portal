class ReportsController < ApplicationController
  load_and_authorize_resource
  before_filter { @top_tab = 'reports' }
  before_action :set_report, only: [:show, :edit, :update, :destroy, :edit_points, :points]

  # GET /reports
  def index
    if current_user.advisor?
      klasses = Klass.where(group_id: current_user.group_id)
      klass_ids = klasses.collect(&:id)
      @reports = Report.where(klass_id: klass_ids)
    elsif current_user.higher_than? 'advisor'
      klasses = @school.groups.includes(:klasses).collect(&:klasses).flatten
      klass_ids = klasses.collect(&:id)
      @reports = Report.where(klass_id: klass_ids)
    else
      return redirect_to '/'
    end
  end

  # GET /reports/1
  def show
    @report_courses = @report.report_courses.includes(:course)
    report_course_ids = @report_courses.collect(&:course_id)
    @canAddCourse = @report.klass.courses.reject{|course| report_course_ids.include?(course.id)}.size > 0
    @tab = params[:tab] || ''
    if @tab != 'points'
      @users = @report.users
      @points = @report.report_courses.includes(:points).collect(&:points).flatten
    end
  end

  # GET /reports/new
  def new
    if current_user.advisor?
      @klasses = Klass.where(group_id: current_user.group_id)
    elsif current_user.higher_than? 'advisor'
      @groups = @school.groups.includes(:klasses)
      @klasses = @groups.collect(&:klasses).flatten
    end
    @report = Report.new
  end

  # GET /reports/1/edit
  def edit
  end

  # POST /reports
  def create
    if current_user.advisor?
      @klasses = Klass.where(group_id: current_user.group_id)
    elsif current_user.higher_than? 'advisor'
      @groups = @school.groups.includes(:klasses)
      @klasses = @groups.collect(&:klasses).flatten
    end
    @report = Report.new(report_params)
    @report.start_date = get_date(params[:start_year], params[:start_month], params[:start_day])
    @report.end_date = get_date(params[:end_year], params[:end_month], params[:end_day])
    unless @klasses.collect(&:id).include? @report.klass_id
      return render action: 'new'
    end
    if @report.save
      redirect_to @report
    else
      render action: 'new'
    end
  end

  # PATCH/PUT /reports/1
  def update
    if @report.update(report_params)
      redirect_to @report#, notice: 'Report was successfully updated.'
    else
      render action: 'edit'
    end
  end

  # DELETE /reports/1
  def destroy
    @report.destroy
    redirect_to reports_url#, notice: 'Report was successfully destroyed.'
  end

  def delete_course
    authorize! :manage, @report
    @course_id = params[:course_id].to_i
    @course = @report.report_courses.where(id: @course_id).first
    unless @course.nil?
      @course.destroy
    end
    @report.regenerate_points
    redirect_to @report
  end

  def edit_points
    authorize! :manage, @report
    @course_id = params[:course_id].to_i
    @courses = @report.report_courses.includes(:course)
    @course = @courses.where(course_id: @course_id).first
    if @courses.where(course_id: @course_id).first.nil?
      redirect_to @report
    end
    @points = @courses.collect(&:points).flatten
  end

  def points
    authorize! :manage, @report
    @course_id = params[:course_id].to_i
    @courses = @report.report_courses.includes(:course)
    if @courses.where(course_id: @course_id).first.nil?
      redirect_to @report
    end
    @course = @courses.where(course_id: @course_id).first
    exam_homework_part = params[:exam_homework_part].to_i.abs
    exam_quiz_part = params[:exam_quiz_part].to_i.abs
    if exam_quiz_part+exam_homework_part > @report.max_grade
      exam_homework_part = @report.max_grade - (exam_quiz_part = @report.max_grade if exam_quiz_part > @report.max_grade)
    end
    multiplier = params[:multiplier].to_i
    @course.update exam_homework_part: exam_homework_part, exam_quiz_part: exam_quiz_part, multiplier: multiplier
    @points = @course.points
    save_points params[:point]
    redirect_to controller: :reports, action: :show, id: @report.id, tab: 'points'
  end

  def add_course_form
    authorize! :manage, @report
    @report_courses = @report.report_courses.includes(:course)
    report_course_ids = @report_courses.collect(&:course_id)
    @courses = @report.klass.courses.reject{|course| report_course_ids.include?(course.id)}
    @course = @report.report_courses.build
  end

  def add_course
    authorize! :manage, @report
    @report_courses = @report.report_courses.includes(:course)
    @courses = @report.klass.courses
    @course_id = params[:course_id].to_i
    @course = @report.report_courses.build
    if not @report.klass.course_ids.include? @course_id
      return render 'add_course_form'
    end
    exam_homework_part = params[:exam_homework_part].to_i.abs
    exam_quiz_part = params[:exam_quiz_part].to_i.abs
    if exam_quiz_part+exam_homework_part > @report.max_grade
      exam_homework_part = @report.max_grade - (exam_quiz_part = @report.max_grade if exam_quiz_part > @report.max_grade)
    end
    @course = @report.report_courses.create exam_homework_part: exam_homework_part, exam_quiz_part: exam_quiz_part, course_id: @course_id, multiplier: params[:multiplier].to_i
    @points = @course.points
    save_points params[:point]
    redirect_to controller: :reports, action: :show, id: @report.id, tab: 'points'
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_report
      @report = Report.find(params[:id])
    end

    # Only allow a trusted parameter "white list" through.
    def report_params
      params.require(:report).permit(:name, :klass_id, :published,:start_date, :end_date, :max_grade, :ranking, :objection, :objection_limit, :objection_courses, user_ids: [])
    end

    def get_date(year, month, day)
      JalaliDate.new(year.to_i, month.to_i, day.to_i).to_g
    end

    def save_points point_params
      report_users = @report.report_users.to_a
      ActiveRecord::Base.transaction do
        point_params.each do |user_id, mark|
          report_user = report_users.find{|u| u.user_id == user_id.to_i }
          unless report_user
            report_user = @report.report_users.create user_id: user_id
          end
          point = @points.where(user_id: user_id.to_i).first
          if point
            point.bare_point = mark.to_d
          else
            point = @course.points.build({user_id: user_id.to_i, bare_point: mark.to_d})
          end
          if point.bare_point && point.bare_point > @report.max_grade
            point.bare_point = @report.max_grade
          end
          point.save
        end
      end
      @report.regenerate_points
    end
end
