class KlassesController < ApplicationController
  before_action :set_klass, only: [:edit, :update, :destroy]

  # GET /klasses/new
  def new
    if current_user.advisor?
      @group = current_user.group
    elsif current_user.user_type >= APP_CONFIG['user_types']['manager']
      @groups = @school.groups
      if @groups.collect(&:id).include? params[:group_id].to_i
        @group_id = params[:group_id]
      else
        @group_id = @groups.first
      end
    end
    @klass = Klass.new group: @group
  end

  # POST /klasses
  def create
    _params = klass_params
    _params.delete :user_ids
    @klass = Klass.new(_params)
    if current_user.advisor?
      @group_id = current_user.group_id
      @klass.group_id = @group_id
    elsif current_user.user_type >= APP_CONFIG['user_types']['manager']
      unless @school.group_ids.include? _params[:group_id].to_i
        flash[:error] = "خطایی رخ داده است"
        @groups = @school.groups
        return render action: 'new'
      end
      @klass.group_id = _params[:group_id]
    end
    if @klass.save
      if ['1', 'yes', 'on', 'true', true, 't'].include? params[:copy]
        copy_klass = Klass.find(params[:copy_klass_id])
        if (current_user.advisor? and copy_klass.group_id == current_user.group_id) or 
           (current_user.user_type >= APP_CONFIG['user_types']['manager'] and copy_klass.group.school_id == @school.id)
          @klass.copy_from(copy_klass)
        end
      end
      redirect_to edit_klass_path(@klass), notice: 'کلاس با موفقیت ایجاد شد.'
    else
      @groups = @school.groups
      flash[:error] = @klass.errors.messages.inject(''){|m, i| m+', '+i[1].join(', ')}
      render action: 'new'
    end
  end

  # GET /klasses/1/edit
  def edit
    if current_user.advisor?
      return redirect_to '/settings' unless @klass.group_id == current_user.group_id
    elsif current_user.user_type >= APP_CONFIG['user_types']['manager']
      return redirect_to '/settings' unless @school.group_ids.include? @klass.group_id
    end
    @users = User.type_students.where(group_id: @klass.group_id)
  end

  # PATCH/PUT /klasses/1
  def update
    if current_user.advisor?
      return redirect_to '/settings' unless @klass.group_id == current_user.group_id
    elsif current_user.user_type >= APP_CONFIG['user_types']['manager']
      return redirect_to '/settings' unless @school.group_ids.include? @klass.group_id
    end
    _params = klass_params
    _params.delete :group_id
    if @klass.update(_params)
      redirect_to '/settings'
    else
      @users = User.type_students.where(group_id: @klass.group_id)
      render action: 'edit'
    end
  end

  # DELETE /klasses/1
  def destroy
    if current_user.advisor?
      return redirect_to '/settings' unless @klass.group_id == current_user.group_id
    elsif current_user.user_type >= APP_CONFIG['user_types']['manager']
      return redirect_to '/settings' unless @school.group_ids.include? @klass.group_id
    end
    @klass.destroy
    redirect_to '/settings', notice: 'کلاس حذف شد.'
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_klass
      @klass = Klass.find(params[:id])
    end

    # Only allow a trusted parameter "white list" through.
    def klass_params
      params.require(:klass).permit(:group_id, :name, user_ids: [])
    end
end
