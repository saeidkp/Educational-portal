class ApplicationController < ActionController::Base
          # Prevent CSRF attacks by raising an exception.
  # For APIs, you may want to use :null_session instead.   protect_from_forgery with: :exception

  before_filter do
    if ['advisories','courses','exams','klasses','messages','news','pages','polls','schools','topics','users'].include?(controller_name) and
        not user_signed_in? and request.fullpath != new_user_session_path
      return redirect_to new_user_session_path
    end
    if current_user
      if !current_user.last_activity or current_user.last_activity < DateTime.now-10.minutes
        current_user.update last_activity: DateTime.now
      end
      current_user.check_activity
    end
  end

  before_filter :configure_permitted_parameters, if: :devise_controller?

  before_filter do
    resource = controller_name.singularize.to_sym
    method = "#{resource}_params"
    params[resource] &&= send(method) if respond_to?(method, true)
  end

  before_filter do
    if controller_name == 'exams'
      if ['create', 'update'].include? params[:action]
        change_date request.params
      end
      # if params[:action] == 'points'
      #   puts ">> #{params[:exam][:points_attributes]}"
      #   puts ">> #{request.params[:exam][:points_attributes]}"
      #   params[:exam][:points_attributes] = request.params[:exam][:points_attributes]
      # end
    elsif controller_name == 'users' and ['update'].include? params[:action]
      change_date request.params
    end
  end

  before_action do
    if current_user
      if current_user.admin?
        if session[:school_id]
          @school = School.where(id: session[:school_id]).first
          unless @school
	          session[:school_id] = nil
            return redirect_to '/settings'
          end
        elsif School.count > 0
          @school = School.first
          session[:school_id] = @school.id
	      elsif controller_name != 'pagse'
          if controller_name != 'schools'
	          return redirect_to '/schools'
          end
        elsif controller_name == 'pages' and not ['update_me', 'balance', 'add_balance', 'update_password'].include? params[:action]
          return redirect_to '/schools'
        end
      else
        @school = current_user.school
      end
    end
  end

  def respond_to_forbidden
    render text: File.read(Rails.root.join('public', '403.html').to_s), status: 403
  end

  def respond_to_not_found
    render text: File.read(Rails.root.join('public', '404.html').to_s), status: 404
  end

  after_filter :store_location

  def store_location
    # store last url - this is needed for post-login redirect to whatever the user last visited.
    if (request.fullpath != "/users/sign_in" &&
        request.fullpath != "/users/sign_up" &&
        request.fullpath != "/users/password" &&
        request.fullpath != "/users/sign_out" &&
        !request.fullpath =~ /^\/user\/password/ &&
        !request.xhr?) # don't store ajax calls
      session[:previous_url] = request.fullpath 
    end
  end

  def after_update_path_for(resource)
    session[:previous_url] || root_path
  end
  
  def after_sign_in_path_for(resource)
    session[:previous_url] || root_path
  end

  protected

  def configure_permitted_parameters
    devise_parameter_sanitizer.for(:sign_up) { |u| u.permit(:username, :password, :password_confirmation, :remember_me) }
    devise_parameter_sanitizer.for(:sign_in) { |u| u.permit(:username, :password, :remember_me) }
    devise_parameter_sanitizer.for(:account_update) { |u| u.permit(:username, :password, :password_confirmation, :current_password) }
  end

  rescue_from CanCan::AccessDenied do |exception|
    # In a proper way use respond_to_not_found (not for development)
    respond_to_forbidden
  end

  rescue_from ActiveRecord::RecordNotFound do |e|
    respond_to_not_found
  end

end
