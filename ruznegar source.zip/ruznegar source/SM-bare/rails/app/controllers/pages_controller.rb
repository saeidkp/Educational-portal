class PagesController < ApplicationController
  def index
    @news = if @school
      News.where(school_id: [@school.id, nil]).order(created_at: :desc).limit(10)
    else
      []
    end
    date = Date.today
    date_next = Date.today.next_month
    @events = if @school
      if current_user.higher_than? 'advisor'
        Event.where(school_id: @school.id, date: date..date_next).order('id ASC').limit(5).entries
      else
        Event.where(school_id: @school.id, group_id: current_user.group_id, date: date...date_next).order('id ASC').entries
      end
    else
      []
    end
    @polls = if current_user.student?
      Poll.for_student(current_user)
    elsif current_user.parent?
      Poll.for_parent(current_user)
    end
    @advisories = if current_user.student?
      Advisory.where(user_id: current_user.id).where('"advisories"."date" > ?', Date.today-1.days).to_a
    elsif current_user.parent?
      Advisory.where(user_id: current_user.parent_of_id).where('"advisories"."date" > ?', Date.today-1.days).to_a
    end
  end

  def me
    @tab = params[:tab] || ''
    @user = current_user
    if @tab == 'courses'
      if @user.advisor?
        @courses = @user.group.courses
      elsif @user.student?
        @courses = @user.courses
      elsif @user.parent?
        @courses = @user.parent_of.courses
      elsif @user.teacher?
        @courses = @user.teachings
      end
    end
  end

  def settings
    if current_user.advisor?
      @group = Group.includes(:klasses).find current_user.group_id
      @klasses = @group.klasses
      render 'settings_advisor'
    elsif current_user.higher_than? 'advisor'
      if current_user.admin?
        @schools = School.all
      end
      @groups = Group.includes(:klasses).where(school_id: @school.id)
      @klasses = @groups.collect(&:klasses).flatten
      render 'settings_manager'
    else
      redirect_to '/'
    end
  end

  def save_settings
    if current_user.admin?
      if params[:school]
        session[:school_id] = params[:school]
        return redirect_to root_path
      end
      upd = {}
      upd[:sms_price] = params[:sms_price] if params[:sms_price]
      upd[:only_super_admin] = ['true', true, 'yes', 1].include?(params[:only_super_admin])
      if upd[:only_super_admin]
        User.type_admins.where(super_admin: false).each(&:lock_access!)
      else
        User.type_admins.where(super_admin: false).each(&:unlock_access!)
      end
      if upd.length
        Settings.first.update upd
      end
    redirect_to settings_path
    else
      redirect_to '/'
    end
  end

  def update_me
    if !current_user.student?
      valid_fields = ['name', 'self_phone', 'password', 'password_confirmation', 'username']
      user_params = params[:user].select{|f| valid_fields.include? f}
      current_user.update_attributes user_params
      if current_user.valid?
        redirect_to '/me'
      else
        redirect_to '/me?tab=edit'
      end
    else
      redirect_to '/me'
    end
  end

  def time
    @time = TopicTableTime.find(params[:id])
    if current_user.advisor?
      unless @time.topic_table.topic.klass.group_id == current_user.group_id
        raise CanCan::AccessDenied
      end
    elsif current_user.higher_than? 'advisor'
      unless @time.topic_table.topic.klass.group.school_id == @school.id
        raise CanCan::AccessDenied
      end
    else
      raise CanCan::AccessDenied
    end
  end

  def edit_time
    @time = TopicTableTime.find(params[:id])
    if current_user.advisor?
      unless @time.topic_table.topic.klass.group_id == current_user.group_id
        raise CanCan::AccessDenied
      end
    elsif current_user.higher_than? 'advisor'
      unless @time.topic_table.topic.klass.group.school_id == @school.id
        raise CanCan::AccessDenied
      end
    else
      raise CanCan::AccessDenied
    end
    valid_fields = ['minutes', 'time_type']
    if @time.update params.select{|f| valid_fields.include? f}
      redirect_to topic_path @time.topic_table.topic
    else
      render action: 'new_time'
    end
  end

  def new_time
    if params[:table_id]
      @table = TopicTable.find params[:table_id]
    end
    if current_user.advisor?
      unless @table.topic.klass.group_id == current_user.group_id
        raise CanCan::AccessDenied
      end
    elsif current_user.higher_than? 'advisor'
      unless @table.topic.klass.group.school_id == @school.id
        raise CanCan::AccessDenied
      end
    else
      raise CanCan::AccessDenied
    end
    @courses = @table.topic.klass.courses
    @time = TopicTableTime.new topic_table_id: @table.id
  end

  def create_time
    if params[:table_id]
      @table = TopicTable.find params[:table_id]
    end
    if current_user.advisor?
      unless @table.topic.klass.group_id == current_user.group_id
        raise CanCan::AccessDenied
      end
    elsif current_user.higher_than? 'advisor'
      unless @table.topic.klass.group.school_id == @school.id
        raise CanCan::AccessDenied
      end
    else
      raise CanCan::AccessDenied
    end
    @courses = @table.topic.klass.courses
    valid_fields = ['minutes', 'time_type', 'course_id']
    @time = TopicTableTime.new params.select{|f| valid_fields.include? f}.merge(topic_table_id: @table.id)
    if @courses.collect(&:id).include? @time.course_id
      if @time.save
        redirect_to topic_path @table.topic
      else
        render action: 'new_time'
      end
    else
      render action: 'new_time'
    end
  end

  def destroy_time
    @time = TopicTableTime.find(params[:id])
    if current_user.advisor?
      unless @time.topic_table.topic.klass.group_id == current_user.group_id
        raise CanCan::AccessDenied
      end
    elsif current_user.higher_than? 'advisor'
      unless @time.topic_table.topic.klass.group.school_id == @school.id
        raise CanCan::AccessDenied
      end
    else
      raise CanCan::AccessDenied
    end
    @topic = @time.topic_table.topic
    @time.destroy
    redirect_to @topic
  end

  def new_table
    @topic_id = params[:topic_id]
    if @topic_id
      @topic = Topic.find(@topic_id)
      if current_user.advisor?
        unless @topic.klass.group_id == current_user.group_id
          raise CanCan::AccessDenied
        end
      elsif current_user.higher_than? 'advisor'
        unless @topic.klass.group.school_id == @school.id
          raise CanCan::AccessDenied
        end
      else
        raise CanCan::AccessDenied
      end
      _params = {}
      if params[:user] and @topic.klass.user_ids.include? params[:user].to_i
        _params[:user_ids] = params[:user]
      end
      @table = @topic.tables.build _params
    else
      redirect_to topics_path
    end
  end

  def create_table
    @topic_id = params[:topic_id]
    if @topic_id
      @topic = Topic.find(@topic_id)
      if current_user.advisor?
        unless @topic.klass.group_id == current_user.group_id
          raise CanCan::AccessDenied
        end
      elsif current_user.higher_than? 'advisor'
        unless @topic.klass.group.school_id == @school.id
          raise CanCan::AccessDenied
        end
      else
        raise CanCan::AccessDenied
      end
      _params = {topic_id: @topic.id, user_ids: params[:user_ids] || []}
      @table = @topic.tables.build _params
      if @table.save
        redirect_to @topic
      else
        render action: 'new_table'
      end
    else
      redirect_to topics_path
    end
  end

  def destroy_table
    @table = TopicTable.find params[:id]
    @topic = Topic.includes(:users).find @table.topic_id
    return redirect_to @topic if @table.is_default
    if current_user.advisor?
      unless @topic.klass.group_id == current_user.group_id
        raise CanCan::AccessDenied
      end
    elsif current_user.higher_than? 'advisor'
      unless @topic.klass.group.school_id == @school.id
        raise CanCan::AccessDenied
      end
    else
      raise CanCan::AccessDenied
    end
    @table.destroy
    redirect_to @topic
  end

  def edit_table
    @table = TopicTable.find params[:id]
    @topic = Topic.includes(:users).find @table.topic_id
    return redirect_to @topic if @table.is_default
    if current_user.advisor?
      unless @topic.klass.group_id == current_user.group_id
        raise CanCan::AccessDenied
      end
    elsif current_user.higher_than? 'advisor'
      unless @topic.klass.group.school_id == @school.id
        raise CanCan::AccessDenied
      end
    else
      raise CanCan::AccessDenied
    end
  end

  def update_table
    @table = TopicTable.find params[:id]
    @topic = Topic.includes(:users).find @table.topic_id
    return redirect_to @topic if @table.is_default
    if current_user.advisor?
      unless @topic.klass.group_id == current_user.group_id
        raise CanCan::AccessDenied
      end
    elsif current_user.higher_than? 'advisor'
      unless @topic.klass.group.school_id == @school.id
        raise CanCan::AccessDenied
      end
    else
      raise CanCan::AccessDenied
    end
    _params = {user_ids: params[:user_ids] || []}
    if @table.update _params
      redirect_to @topic
    else
      render action: 'edit_table'
    end
  end

  def weekly_table
    if current_user.teacher?
      redirect_to '/'
    end
    prepare_weekly_table
  end

  def edit_weekly_table
    if not current_user.higher_than? "teacher"
      redirect_to '/'
    end
    prepare_weekly_table
    @courses = @table.klass.courses
  end

  def save_weekly_table
    if not current_user.higher_than? "teacher"
      redirect_to '/'
    end
    prepare_weekly_table
    @courses = @table.klass.courses
    if params[:table]
      ActiveRecord::Base.transaction do
        params[:table].each do |day,etc|
          etc.each do |hour,_table|
            time = @times.find{|t| t.hour == hour.to_i && t.day == day.to_i}
            if time
              time.opt_text = _table[:opt_text]
              time.course_id = _table[:course]
              if ['1', 'yes', 'on', 'true', true, 't'].include?(_table[:takzang]) && time.course_id && _table[:course_2]
                time.second_course_id = _table[:course_2]
                time.tak_zang = true
              else
                time.second_course_id = nil
                time.tak_zang = false
              end
              time.save
            end
          end
        end
      end
      redirect_to weekly_table_path, klass_id: @klass_id
    else
      render 'edit_weekly_table'
    end
  end

  def calendar
    prepare_calendar
  end

  def calendar_edit
    return redirect_to calendar_path unless calendar_edit_permission
    prepare_calendar
  end

  def calendar_edit_save
    return redirect_to calendar_path unless calendar_edit_permission
    prepare_calendar
    if params[:calendar]
      can_group = current_user.higher_than?('advisor') and params[:calendar][:group]
      groups_ids = @groups.collect(&:id)
      ActiveRecord::Base.transaction do
        if params[:calendar][:event]
          params[:calendar][:event].each do |id,title|
            event = @events.find{|e| e.id == id.to_i}
            if event
              if (current_user.advisor? and event.group_id == current_user.group_id) or (current_user.manager? and event.school_id == current_user.school_id) or current_user.admin?
                if title and title != ''
                  event.update title: title
                else
                  event.destroy
                end
              end
            end
          end
        end
        is_admin = current_user.admin?
        if params[:calendar][:day]
          params[:calendar][:day].each do |day, events|
            if events
              events.each do |i, title|
                if title and title != ''
                  _attributes = {school_id: @school.id, title: title}
                  _attributes[:date] = JalaliDate.new(@year, @month, day.to_i).to_g
                  _attributes[:off] = params[:calendar][:off][day][i] if is_admin
                  # Rails.logger.debug ">> #{params[:calendar][:off][day][i]}"
                  _attributes[:global] = false
                  if current_user.advisor?
                    _attributes[:group_id] = current_user.group_id
                  elsif can_group and current_user.admin? and params[:calendar][:group][day][i] == 'global'
                    _attributes[:group_id] = nil
                    _attributes[:school_id] = nil
                    _attributes[:global] = true
                  elsif can_group and params[:calendar][:group][day] and params[:calendar][:group][day][i] and groups_ids.include?(params[:calendar][:group][day][i].to_i)
                    _attributes[:group_id] = params[:calendar][:group][day][i]
                  end
                  Event.create(_attributes)
                end
              end
            end
          end
        end
      end
      return redirect_to calendar_path(group: @group_id, month: @jdate.month, year: @jdate.year)
    else
    end
    return redirect_to calendar_path(group: @group_id, month: @jdate.month, year: @jdate.year)
  end

  def destroy_event
    return redirect_to calendar_path unless calendar_edit_permission
    event = Event.find(params[:id])
    if current_user.advisor?
      if event.group_id == current_user.group_id
        event.destroy
      end
    elsif current_user.manager?
      if event.school_id == current_user.school_id and not event.global
        event.destroy
      end
    elsif current_user.admin?
      event.destroy
    end
    return redirect_to request.referer
  end

  def readings
    return redirect_to '/' unless current_user.student?
    @topic = current_user.topic
    if @topic
      @table = current_user.topic_table || @topic.default_table
    end
    if @table
      @courses = @table.times.includes(:course).collect(&:course)
    end
    if params[:date]
      @date = Date.parse(params[:date])
      @user_readings = current_user.readings.where(date: @date).entries
    end
  rescue ArgumentError
    flash[:notice] = "خطا: تاریخ آدرس اشتباه است."
    return redirect_to readings_path
  end

  def save_readings
    return redirect_to '/' unless current_user.student?
    @topic = current_user.topic
    @table = current_user.topic_table
    @table = @topic.default_table if not @table and @topic
    if @table
      @courses = @table.times.includes(:course).collect(&:course)
    else
      flash[:notice] = "جدول مطالعه برای این کاربر تعیین نشده است."
      return redirect_to readings_path
    end
    if params[:date]
      @date = Date.parse(params[:date])
      @user_readings = current_user.readings.where(date: @date).entries
    else
      return redirect_to readings_path
    end
    if params[:course]
      ActiveRecord::Base.transaction do
        Rails.logger.debug ">> #{params[:course]}"
        params[:course].each do |course_id, data|
          if data[:duration].to_i > 0 or not data[:content].blank?
            reading = @user_readings.find{|r| r.course_id == course_id.to_i}
            reading = current_user.readings.build(course_id: course_id.to_i, date: @date) unless reading
            reading.duration = data[:duration]
            reading.content = data[:content]
            reading.start = data[:start]
            reading.save
          end
        end
      end
    else
      flash[:error] = "خطا: اطلاعات وارد شده غیر قابل قبول است."
      return redirect_to readings_path(date: @date)
    end
    flash[:success] = "مطالعه ثبت شد."
    return redirect_to readings_path(date: @date)
  rescue ArgumentError
    flash[:notice] = "خطا: تاریخ آدرس اشتباه است."
    return redirect_to readings_path
  end

  def printable_objection
    return redirect_to '/' unless current_user.higher_than?('teacher')
    if params[:id]
      @report = Report.find(params[:id])
      if current_user.advisor?
        unless @report.klass.group_id == current_user.group_id
          return redirect_to '/'
        end
      else
        unless @report.klass.group.school_id == @school.id 
          return redirect_to '/'
        end
      end
      @objections = @report.objections
    else
      return redirect_to '/'
    end
    render layout: 'report'
  end

  def printable_report
    return redirect_to '/' unless current_user.higher_than?('teacher')
    if params[:report]
      @report = Report.find(params[:report])
      if current_user.advisor?
        unless @report.klass.group_id == current_user.group_id
          return redirect_to '/'
        end
      else
        unless @report.klass.group.school_id == @school.id 
          return redirect_to '/'
        end
      end
      @report_users = if params[:user]
        @report.report_users.includes(:user).where(user_id: params[:user])
      else
        @report.report_users.includes(:user)
      end
    else
      return redirect_to '/'
    end
    render layout: 'report'
  end

  def printable_report_course
    return redirect_to '/' unless current_user.higher_than?('teacher')
    if params[:report]
      @report = Report.find(params[:report])
      if current_user.advisor?
        unless @report.klass.group_id == current_user.group_id
          return redirect_to '/'
        end
      else
        unless @report.klass.group.school_id == @school.id 
          return redirect_to '/'
        end
      end
      @report_courses = if params[:course]
        @report.report_courses.includes(:points).where(id: params[:course])
      else
        @report.report_courses.includes(:points)
      end
      @report_users = @report.report_users
    else
      return redirect_to '/'
    end
    render layout: 'report'
  end

  def printable_activity
    return redirect_to '/' unless current_user.higher_than?('teacher')
    return redirect_to '/' unless params[:klass]
    @klass = Klass.includes(:courses).find(params[:klass])
    if current_user.advisor?
      return redirect_to '/' unless @klass.group_id == current_user.group_id
    else
      return redirect_to '/' unless @klass.group.school_id == @school.id 
    end
    begin
      if params[:start_date] and params[:end_date]
        start_params = params[:start_date].split('/').collect(&:to_i)
        @start_date = JalaliDate.new(*start_params).to_g
        end_params = params[:end_date].split('/').collect(&:to_i)
        @end_date = JalaliDate.new(*end_params).to_g
      else
        @start_date = Date.today
        jdate = JalaliDate.new @start_date
        jend_date = JalaliDate.today
        jend_date.day = 1
        jend_date.month = 7
        jend_date.year = jdate.month < 7 ? jdate.year - 1 : jdate.year
        @end_date = jend_date.to_g
      end
    rescue
      return render text: "خطا در پردازش تاریخ"
    end
    if not params[:course].blank?
      @courses = [@klass.courses.find(params[:course])]
    else
      @courses = @klass.courses
    end
    course_ids = @courses.collect(&:id)
    @exams = Exam.where(course_id: course_ids, date: @start_date..@end_date).group_by(&:course_id)
    @users = if not params[:user].blank?
      @klass.users.where(id: params[:user])
    else
      @klass.users
    end
    report_users = ReportUser.where(user_id: @users.collect(&:id))
    report_courses = ReportCourse.where(report_id: report_users.collect(&:report_id), course_id: course_ids).includes(:points)

    @report_points = {}
    report_courses.each do |rc|
      @report_points[rc.course_id] ||= []
      @report_points[rc.course_id] += rc.points
    end
    render layout: 'report'
  end

  def show_reports
    raise CanCan::AccessDenied unless current_user.higher_than? 'teacher'
    current_user.group
    @groups = if current_user.advisor?
      [current_user.group]
    else
      @school.groups.includes(:klasses)
    end
    @klasses = @groups.collect(&:klasses).flatten
    if params[:class]
      k_id = params[:class].to_i
      @klass = @klasses.find{|k| k.id == k_id}
    end
    @start_date = JalaliDate.new(@school.created_at)
    @start_date.day = 1
    @end_date = JalaliDate.today
    if @end_date.month == 12
      @end_date.year += 1
      @end_date.month = 1
    else
      @end_date.month += 1
    end
  end

  def grades
    @user = if current_user.student?
      current_user
    elsif current_user.parent?
      current_user.parent_of
    else
      nil
    end
    return unless @user
    @reports = ReportUser.includes(:report,:objections).where(user_id: @user.id).to_a.select{|ru| ru.report.published}
    @points = ReportPoint.includes(:report_course).where(user_id: @user.id).to_a
    @objections = @reports.collect(&:objections).flatten
    if params[:object] and params[:course]
      @object_report = @reports.find{|r| r.report_id == params[:object].to_i}
      if @object_report
        @object_course = @object_report.report.report_courses.where(id: params[:course]).first
        @objection = @object_report.objections.where(report_course_id: @object_course.id).first
        if @objection
          if params[:text]
            if Time.now-@objection.created_at < 5.minutes
              @objection.text = params[:text]
            else
              flash[:error] = "شما در این درس قبلا اعتراض کرده‌اید و قادر به تغییر آن نیستید."
            end
          end
        elsif @object_report.report.can_object(@object_report)
          @objection = @object_report.objections.build(report_course_id: @object_course.id, text: params[:text], report_id: @object_report.report_id)
        else
          flash[:notice] = "شما مجاز به اعتراض در این درس نیستید."
        end
      end
    end
  end

  def objection
    self.grades()
    @objection.save() if @objection
    redirect_to '/grades'
  end

  def stats
    return redirect_to root_path unless current_user.higher_than? 'teacher'
    @page = (params[:page] || 1).to_i
    if params[:user]
      user = User.find(params[:user])
      unless (current_user.advisor? and user.group_id == current_user.group_id) or user.school_id == @school.id
        redirect_to stats_path
      end
      @user_id = user.id
      @users = [user]
    end
    if current_user.advisor?
      @users_list = current_user.group.users
    else
      @users_list = @school.users
    end
    if not @users
      @users = @users_list
    end
    @activities = Activity.where(user_id: @users.collect(&:id)).order('time DESC').page(@page).per(50)
  end

  def balance; end

  def add_balance
    type = params[:type].to_i
    val = ({0 => 1, 1 => 2, 2 => 5})[type] || 1
    order = Order.incomplete.create user: current_user, amount: val*10*1000 # val*10k rials
    order.request
    if order.refId
      @refId = order.refId
    else
      flash[:notice] = "خطا در اتصال"
      order.destroy
    end
    render 'balance'
  end

  def checkOrder
    order = Order.incomplete.where(id: params[:saleOrderId]).first
    if order
      res_code = params[:ResCode]
      if res_code == 0
        user.update balance: user.balance+order.amount
        flass[:success] = "حساب شما با موفقیت افزایش یافت."
      else
        flass[:error] = "خطا در عملیات بانکی"
        Rails.logger.info ">> BANK: #{res_code}"
      end
      order.update completed: true
    else
      flash[:error] = "سفارش در سایت موجود نمی‌باشد، شماره‌ی تراکنش شما #{params[:SaleReferenceId]} نمی‌باشد، در صورت مشکل با ادمین سایت تملس بگیرید"
    end
    render 'add_balance'
  end

  def update_password
    return redirect_to me_path unless current_user.student?
    if params[:password] and params[:password].length >= 4 and params[:confirm] and params[:password] == params[:confirm]
      current_user.update password: params[:password]
      flash[:notice] = "پسورد با موفقیت تغییر کرد، دوباره وارد شوید."
    else
      flash[:error] = "رمز عبور حداقل ۴ کاراکتر میبایست باشد، هر دو فیلد باید پر شوند و با هم برابر باشند."
    end
    return redirect_to request.referer
  end

  def test
    render text: @school.id
  end

  def time_table
    if current_user.student?
      return render "time_table_user"
    else
      perpare_time_table
    end
  end

  def time_table_post
    perpare_time_table
    if @selected_user and params[:time] and params[:time].is_a? Hash
      if params[:time].reject{|__, t| t.is_a?(Hash) and t.select{|___, tt| tt =~ /[#|]/}.count == 0}.count == 0
        _table = params[:time].collect{|__,t| t.values.join('#')}.join('|')
        if params[:group] and params[:group].is_a? Array
          klass_ids = []
          group_ids = []
          params[:group].each do |g|
            if g =~ /group-(\d+)/
              group_ids.push g.gsub("group-", '').to_i
            elsif g =~ /klass-(\d+)/
              klass_ids.push g.gsub("klass-", '').to_i
            end
          end
          if current_user.advisor?
            group_ids = group_ids & [current_user.group.id]
            klass_ids = klass_ids & current_user.group.klasses.collect(&:id)
          else
            group_ids = group_ids & @school.groups.collect(&:id)
            klass_ids = klass_ids & @school.groups.collect(&:klasses).flatten.collect(&:id)
          end
          Rails.logger.debug ">> #{group_ids}, #{klass_ids}"
          users = User.type_students.where("group_id in (?) OR klass_id in (?)", group_ids,klass_ids)
          users.update_all time_table: _table
          @selected_user.update time_table: _table
        else
          @selected_user.update time_table: _table
        end
      end
    end
    render "time_table"
  end

  def student_reports
    if current_user.student?
      @user = current_user
    elsif current_user.parent?
      @user = current_user.parent_of
    else
      raise CanCan::AccessDenied
    end
    @reports = @user.reports.includes(:report_courses)
    report_course_ids = @reports.collect(&:report_courses).flatten.collect(&:id)
    @report_points = ReportPoint.where(user_id: @user.id, report_course_id: report_course_ids)
  end

private

  def perpare_time_table
    if current_user.advisor?
      @users = current_user.group.users.type_students
    elsif current_user.higher_than? 'advisor'
      @users = @school.users.type_students
    else
      return respond_to_forbidden
    end
    if user = params[:user]
      begin
        @selected_user = @users.find user
      rescue
      end
    end
  end

  def prepare_weekly_table
    case current_user.user_type
    when APP_CONFIG['user_types']['manager'],APP_CONFIG['user_types']['admin']
      if params[:group_id]
        @groups = @school.groups.includes(:klasses).entries
        @group = @groups.find{|g| g.id == params[:group_id].to_i}
        @group ||= @groups.first
        @klasses = @group.klasses
        if params[:klass_id]
          @klass = @group.klasses.to_a.find{|k| k.id == params[:klass_id].to_i}
        end
        @klass ||= @group.klasses.first
      else
        @groups = @school.groups.includes(:klasses).entries
        @group = @groups.first
        @klasses = @group.klasses
        @klass = @klasses.first
      end
    when APP_CONFIG['user_types']['advisor']
      @klasses = current_user.group.klasses.includes(:courses)
      @klass = if params[:klass_id]
        @klasses.find{|k| k.id == params[:klass_id].to_i}
      else
        @klasses.first
      end
      @klass_id = @klass.id
    when APP_CONFIG['user_types']['parent']
      @klass = current_user.parent_of.klass.includes(:courses)
    when APP_CONFIG['user_types']['student']
      @klass = current_user.klass.includes(:courses)
    end
    unless @klass
      flash[:notice] = "#{I18n.t('class')}#{I18n.t('there_is_no')}"
      return redirect_to controller: 'klasses', action: 'new', group_id: @group ? @group.id : nil
    end
    @klass_id = @klass.id
    @group_id = @group.id if @group
    @table = @klass.weekly_table
    @times = @table.class_table_times.entries
  end

  def prepare_calendar
    @top_tab = 'calendar'
    @year = params[:year] ? params[:year].to_i : JalaliDate.today.year
    @month = params[:month] ? params[:month].to_i : JalaliDate.today.month
    @jdate = JalaliDate.new(@year, @month, 1)
    @jdate_next = JalaliDate.new(@month == 12 ? @year+1 : @year, @month == 12 ? 1 : @month+1, 1)
    @jdate_pre = JalaliDate.new(@month == 1 ? @year-1 : @year, @month == 1 ? 12 : @month-1, 1)
    @group_id = params[:group] ? params[:group].to_i : nil
    @events = if current_user.higher_than? 'parent'
      if @group_id
        Event.where(school_id: @school.id, group_id: nil, date: @jdate.to_g...@jdate_next.to_g).order('id ASC').entries+
        Event.where(school_id: @school.id, group_id: @group_id, date: @jdate.to_g...@jdate_next.to_g).order('id ASC').entries
      else
        Event.where(school_id: @school.id, date: @jdate.to_g...@jdate_next.to_g).order('id ASC').entries
      end
    else
      Event.where(school_id: @school.id, group_id: current_user.group_id, date: @jdate.to_g...@jdate_next.to_g).order('id ASC').entries
    end
    @events += Event.where(global: true, date: @jdate.to_g...@jdate_next.to_g).entries
    @groups = @school.groups.entries
  end

  def calendar_edit_permission
    current_user.higher_than? 'teacher'
  end

end