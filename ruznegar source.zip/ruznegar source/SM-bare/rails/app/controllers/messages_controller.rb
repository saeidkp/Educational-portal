class MessagesController < ApplicationController
  before_action :set_message, only: [:show, :destroy]
  before_filter { @top_tab = 'messages' }

  # GET /messages
  def index
    @type = params[:type]
    @type = 'message' unless ['message', 'email', 'sms'].include? @type
    if @type == 'message'
      @sent_messages = params[:tab] == 'sent'
    else
      @sent_messages = true
    end
    if @sent_messages
      @messages = Message.includes(:users).where(from_id: current_user.id, m_type: APP_CONFIG['message_type'][@type]).order(created_at: :desc).page(params[:page] || 0).per(50)
    else
      @messages = current_user.messages.where(m_type: APP_CONFIG['message_type'][@type]).limit(20).order(created_at: :desc).page(params[:page] || 0).per(50)
    end
    @last_check_message = current_user.last_check_message
    current_user.update_attributes has_message: false, last_check_message: DateTime.now
  end

  # GET /messages/1
  def show
  end

  # GET /messages/new
  def new
    prepare_new
    @selected = []
    @message = Message.new
  end

  # POST /messages
  def create
    group_select = params["group-select"]
    _params = message_params.merge(from_id: current_user.id)
    m_type = _params[:m_type].to_i
    prepare_new
    unless current_user.higher_than?('teacher') and [0,1,2].include? m_type
      m_type = 0
    end
    # return render action: 'new' if true
    from = {}
    if group_select and current_user.higher_than? 'teacher'
      group_select.each do |group|
        if group =~ /klass-(\d+)/
          (from[:klasses] ||= []) << (/klass-(\d+)/.match(group)[1])
        elsif group =~ /group-(\d+)/
          (from[:groups] ||= []) << (/group-(\d+)/.match(group)[1])
        elsif group =~ /user-(\w+)/
          (from[:users] ||= []) << (/user-(\w+)/.match(group)[1])
        end
      end
      if from[:klasses]
        from[:klasses] = @klasses.collect(&:id).collect(&:to_i) & from[:klasses]
      end
      if from[:groups] and @groups
        from[:groups] = @groups.collect(&:id).collect(&:to_i) & from[:groups]
      else
        from.delete :groups
      end
      if from[:users] and current_user.advisor?
        from[:users] = ['student', 'parent'] & from[:users]
      elsif current_user.higher_than? 'advisor'
        from[:users] = ['student', 'parent', 'teacher', 'advisor'] & from[:users]
      else
        form.delete :users
      end
    end
    _params[:m_type] = m_type
    @type = APP_CONFIG['message_type_r'][m_type] || 'message'
    @selected = _params[:to] || params[:to]
    if @selected or from.length > 0
      _to_ids = []
      if @selected.is_a? Array
        if current_user.higher_than?('parent')
          _to_ids = @selected.collect(&:to_i)
        else
          flash[:alert] = "خطایی در ارسال پیش آمده است، لطفا دوباره تلاش کنید."
          return render action: 'new'
        end
      else
        _to_ids = [@selected.to_i]
      end
      _to = @users.select{|u| _to_ids.include? u.id}
      _params.delete :to
      if from[:klasses].is_a? Array
        _to += @klasses.select{|k| from[:klasses].include? k.id.to_s}.collect(&:users)
      end
      if from[:groups].is_a? Array
        _to += @groups.select{|k| from[:groups].include? k.id.to_s}.collect(&:users)
      end
      if from[:users].is_a? Array
        users = []
        if from[:users].include? 'student'
          users += @users.select{|u| u.student?}
        end
        if from[:users].include? 'advisor'
          users += @users.select{|u| u.advisor?}
        end
        if from[:users].include? 'parent'
          users += @users.select{|u| u.parent?}
        end
        if from[:users].include? 'teacher'
          users += @users.select{|u| u.teacher?}
        end
        _to += users
      end
      _to = (_to-[current_user]).uniq
      _params[:user_ids] = _to.collect(&:id)
      if _params[:user_ids].length > 0
        @message = Message.create(_params)
        if @message.valid?
          if @message.sms?
            if @message.send_sms
              flash[:notice] = 'پیام ارسال شد.'
              redirect_to '/'
            else
              flash[:alert] = 'خطا در ارسال اسمس.'
              render action: 'new'
            end
          else
            flash[:notice] = 'پیام ارسال شد.'
            redirect_to '/'
          end
        else
          flash[:alert] = @message.errors.messages.values.first.first
          render action: 'new'
        end
      else
        flash[:alert] = "افراد دریاف‌کننده مشخص نشده است"
        render action: 'new'
      end
    else
      flash[:alert] = "افراد دریاف‌کننده مشخص نشده است"
      render action: 'new'
    end
  end

  # DELETE /messages/1
  def destroy
    @message.destroy
    redirect_to messages_url, notice: 'Message was successfully destroyed.'
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_message
      @message = Message.includes(:from).find(params[:id])
    end

    # Only allow a trusted parameter "white list" through.
    def message_params
      params.require(:message).permit(:content, :m_type, :file)
    end

    def prepare_new
      @has_editor = true
      @type = params[:type] || 'message'
      if APP_CONFIG['message_type'][@type].nil?
        return redirect_to controller: 'messages', action: 'new'
      end
      if (current_user.student? || current_user.parent?) and @type != 'message'
        return redirect_to controller: 'messages', action: 'new'
      end
      @multiple = current_user.higher_than? 'teacher'
      if current_user.student?
        @users = []
        @users << @school.admin
        @users << current_user.group.advisor
        @users += current_user.courses.includes(:teacher).collect(&:teacher)
      elsif current_user.parent?
        @users = []
        @users << @school.admin
        @users << current_user.parent_of.group.advisor
        @users += current_user.parent_of.courses.includes(:teacher).collect(&:teacher)
      elsif current_user.teacher?
        @klasses = current_user.teachings.includes(:users)
        @users = @klasses.collect(&:users).flatten
        # @users += User.type_parents.where(parent_of_id: @users.collect(&:id)).entries
      elsif current_user.advisor?
        @klasses = current_user.group.klasses
        @users = current_user.group.users-[current_user]
      elsif current_user.higher_than? 'advisor'
        @groups = @school.groups.includes(:klasses)
        @klasses = @groups.collect(&:klasses).flatten
        @users = User.where(school_id: @school.id)-[current_user]
      end
    end
end
