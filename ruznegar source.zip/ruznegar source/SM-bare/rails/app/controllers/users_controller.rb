require 'csv'
class UsersController < ApplicationController
  load_and_authorize_resource
  before_filter { @top_tab = 'users' }
  before_action :setup_user, only: [:show, :destroy, :edit, :update, :lock, :unlock]
  
  def index
    raise CanCan::AccessDenied unless current_user.higher_than? 'parent'
    page = params[:page] || 0
    @user_type = params[:type]
    # if current_user.admin?
    #   if @user_type
    #     if @user_type == 'other'
    #       @users = User.where.not(user_type: APP_CONFIG['user_types'][@user_type]).page(page).per(50)
    #     else
    #       @users = User.where(user_type: APP_CONFIG['user_types']['student']).page(page).per(50)
    #     end
    #   else
    #     @users = User.type_students.page(page).per(50)
    #   end
    if @user_type == 'admin' and current_user.admin? and current_user.super_admin
      @users = User.where(user_type: APP_CONFIG['user_types'][@user_type]).order(name: :asc).page(page).per(50)
      return
    end
    if current_user.higher_than?('advisor')
      if @user_type
        @users = User.where(user_type: APP_CONFIG['user_types'][@user_type], school_id: @school.id).order(name: :asc).page(page).per(50)
      else
        @users = User.where(school_id: @school.id).page(page).order(name: :asc).per(50)
      end
      if @user_type == 'student'
        @groups = @school.groups.includes(:klasses)
      end
    elsif current_user.advisor?
      if @user_type
        if @user_type == 'teacher'
          courses = Course.includes(:teacher).where(id: current_user.group.course_ids)
          @users = courses.collect(&:teacher)
        elsif @user_type == 'student'
          @users = User.type_students.where(group_id: current_user.group_id).order(name: :asc).page(page).per(50)
        elsif @user_type == 'parent'
          @users = User.type_parents.where(group_id: current_user.group_id).order(created_at: :desc).page(page).per(50)
        end
      else
        redirect_to users_path(type: 'student')
      end
    elsif current_user.student? or current_user.parent?
      if @user_type
        if @user_type == 'other'
          @users = User.where.not(user_type: APP_CONFIG['user_types']['student'], group_id: current_user.group_id).page(page).per(50)
        elsif @user_type == 'teacher'
          courses = Course.includes(:teacher).where(id: current_user.course_ids)
          @users = courses.collect(&:teacher)
        elsif @user_type == 'student'
          @users = User.type_students.where(group_id: current_user.group_id).page(page).per(50)
        end
      else
        redirect_to users_path(type: 'student')
      end
    elsif current_user.teacher?
      if @user_type
        if @user_type == 'student'
          @users = current_user.teachings.includes(:users).collect(&:users).flatten.uniq.select{|u| u.student?}
          # @users = User.type_students.where(id: current_user.teachings.pluck(:user_ids).flatten.compact).page(page).per(50)
        end
      else
        redirect_to users_path(type: 'student')
      end
    end
  end

  def import
    user_type = params[:user_type] || 'student'
    return redirect_to users_path(type: user_type) unless current_user.higher_than?('advisor')
    if params[:file]
      student_attribute_order = [:username, :name, :home_phone, :self_phone, :birthday, :email, :father_name, :father_phone,
                              :father_email, :father_work, :father_work_name, :mother_name, :mother_phone, :mother_email,
                              :mother_work, :mother_work_name, :address, :address2]
      teacher_attribute_order = [:name, :username, :password, :email, :self_phone]
      xls = Roo::Spreadsheet.open(params[:file].path, extension: 'xlsx')
      _users = []
      if user_type == 'student'
        return redirect_to users_path(type: 'student') unless params[:klass]
        klass = @school.groups.includes(:klasses).collect(&:klasses).flatten.find{|k| k.id.to_s == params[:klass]}
        return redirect_to users_path(type: 'student') unless klass
        ActiveRecord::Base.transaction do
          xls.to_a.each do |r|
            row = r.compact
            if row.count > 0 and row[0].to_i != 0
              attrs = row[1..-1].collect{|a|
                a.is_a?(Float) ? a.to_i.to_s : a.to_s
              }
              attributes = Hash[student_attribute_order.zip attrs]
              # attributes[:username] = attributes[:username].to_i.to_s
              attributes[:klass_id] = klass.id
              attributes[:group_id] = klass.group_id
              attributes[:school_id] = @school.id
              _users << User.type_students.create!(attributes)
            end
          end
        end
      elsif user_type == 'teacher'
        ActiveRecord::Base.transaction do
          xls.to_a.each do |r|
            row = r.compact
            if row.count > 0 and row[0].to_i != 0
              attributes = Hash[teacher_attribute_order.zip row[1..-1]]
              attributes[:school_id] = @school.id
              user = User.type_teachers.create!(attributes)
              user.generated_password = attributes[:password]
              _users << user
            end
          end
        end
      end
      rows = [['نام', 'نام کاربری', 'رمز عبور']]
      _users.each do |user|
        rows << [user.name, user.username, user.generated_password]
      end
      _ret = CSV.generate do |csv|
        rows.each do |row|
          csv << row.collect{|str| str.encode('utf-8')}
        end
      end
      # flash[:success] = "کاربرها با موفقیت اضافه شدند"
      return send_data _ret, disposition: :attachment, filename: "users-imported-#{Time.now}.csv", content_type: 'text/csv'
    else
      return redirect_to users_path(type: user_type)
    end
  # rescue
  #   flash[:alert] = "فایل ورودی دارای اشکال است"
  #   return redirect_to users_path(type: user_type)
  end

  def show
    @message = Message.new
    @tab = params[:tab] || ''
    @date = Date.parse(params[:date]) if params[:date]
    if params[:jd]
      @jd = JalaliDate.new(*(params[:jd].split('/').collect(&:to_i)+[1]))
    else
      jd = JalaliDate.today
      @jd = JalaliDate.new(*[jd.year, jd.month, 1])
    end
    # SEVER: POINT ZERO
    if @user.student?
      if ['courses', 'score', 'reading', 'reading-monthly', 'reading-overal', 'message', ''].include?(@tab)
        if ['courses', 'score', 'reading', 'reading-monthly', 'reading-overal'].include? @tab
          unless (current_user.higher_than?('advisor') and @school.id == @user.school_id) or
                  (current_user.advisor? and current_user.group_id == @user.group_id) or
                  current_user == @user or current_user.parent_of_id == @user.id
            redirect_to controller: 'users', action: 'show'
          end
        end
      else
        redirect_to controller: 'users', action: 'show'
      end
    elsif @tab != ''
      redirect_to controller: 'users', action: 'show'
    end
  # rescue ArgumentError
  #   flash[:notice] = "خطا: تاریخ آدرس اشتباه است."
  #   return redirect_to user_path(@user)
  end

  def lock
    if current_user.admin?
      @user.update_attributes is_active: false
    else
      flash[:error] = "شما دسترسی به ایم بخش را ندارید."
    end
    redirect_to @user
  end

  def unlock
    if current_user.admin?
      @user.update_attributes is_active: true
    else
      flash[:error] = "شما دسترسی به ایم بخش را ندارید."
    end
    redirect_to @user
  end

  def new
    @user_type = APP_CONFIG['user_types'][params[:type]]
    return redirect_to '/' unless @user_type
    @user = User.new(school_id: current_user.school_id, user_type: @user_type)
    if @user.admin?
      return redirect_to '/'  if not current_user.super_admin
    elsif not @user.student? and not @user.teacher?
      return redirect_to '/'
    end
    @groups = @school.groups.includes(:klasses).entries
  end

  def create
    @user = User.new(create_user_params)
    @groups = @school.groups.includes(:klasses).entries
    @user_type = params[:user_type]
    Rails.logger.debug ">> #{@user_type}"
    if @user_type.nil? or [APP_CONFIG['user_types']['student'], APP_CONFIG['user_types']['teacher'], APP_CONFIG['user_types']['admin']].include?(@user_type)
      @user.user_type = APP_CONFIG['user_types']['student']
      flash[:error] = "خطایی رخ داده‌است"
      return render 'new'
    else
      @user.user_type = @user_type
    end
    if @user.admin? and not current_user.super_admin
      flash[:error] = "خطایی دسترسی"
      return render 'new'
    end
    if not @user.admin?
      @user.school_id = @school.id
    end
    if @user.student?
      if params[:klass_id] and @school.groups.includes(:klasses).collect(&:klasses).flatten.collect(&:id).include?(params[:klass_id].to_i)
        @user.klass_id = params[:klass_id].to_i
        @user.group_id = @user.klass.group_id
      else
        flash[:error] = "کلاس دانش‌آموز مشخص نشده است."
        return render 'new'
      end
      @user.password = @user.username[-4..-1]
    end
    if @user.save
      redirect_to @user
    else
      flash[:error] = @user.errors.messages.inject(''){|m, i| m+', '+i[1].join(', ')}
      render "new"
    end
  end

  def edit
  end

  def update
    _params = user_params
    if params[:topic_id] && @user.klass && @user.klass.topic_ids.include?(params[:topic_id].to_i)
      _params[:topic_id] = params[:topic_id].to_i
    end
    if current_user.admin? and _params[:username] and @user.username != _params[:username]
      @user.username_changable = true
    end
    @user.update _params
    if @user.valid?
      @user.save
      redirect_to @user
    else
      flash[:error] = @user.errors.messages.inject(''){|m, i| m+', '+i[1].join(', ')}
      render "edit"
    end
  end

  def add_balance
    return redirect_to root_path if not current_user.admin? or not @user.higher_than?('teacher')
  end

  def add_balance_post
    return redirect_to root_path if not current_user.admin? or not @user.higher_than?('teacher')
    balance = params[:balance]
    @user.update balance: balance.to_i
    redirect_to @user
  end

  def destroy
    if @user.student? or @user.teacher?
      @user.destroy
    end
    redirect_to request.referer
  end

private
  def setup_user
    @user = User.includes(:school, :courses).find(params[:id])
    @school = @user.school
  end

  def create_user_params
    _ret = params.require(:user).permit(:name, :email, :username, :avatar, :self_phone, :home_phone, :father_name,
                                        :father_phone, :father_email, :father_work, :father_work_name, :mother_name, :mother_phone,
                                        :mother_email, :mother_work, :mother_work_name, :address, :address2, :birthday, :password)
    _ret
  end

  def user_params
    _ret = params.require(:user).permit(:name, :email, :username, :avatar, :self_phone, :home_phone, :father_name, :klass_id,
                                        :father_phone, :father_email, :father_work, :father_work_name, :mother_name, :mother_phone,
                                        :mother_email, :mother_work, :mother_work_name, :address, :address2, :birthday, :password)
    if current_user.student?
      _ret.delete :username
    end
    _ret
  end

  def change_date(hash)
    if hash[:user][:birth_year] and hash[:user][:birth_month] and hash[:user][:birth_day]
      date_g = JalaliDate.new(hash[:user][:birth_year].to_i, hash[:user][:birth_month].to_i, hash[:user][:birth_day].to_i).to_g
      birthday = DateTime.new date_g.year, date_g.month, date_g.day
      params[:user][:birthday] = birthday
      hash[:user].delete(:birth_year)
      hash[:user].delete(:birth_month)
      hash[:user].delete(:birth_day)
    end
  end
end
