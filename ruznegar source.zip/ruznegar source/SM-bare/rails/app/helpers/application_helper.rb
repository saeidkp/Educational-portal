module ApplicationHelper
  def unpack_string str
    str.to_s.unpack('U*').map{ |e| (0..9).to_a.include?(e-48) ? e + 1728 : e }.pack('U*')
  end

  def unpack_float str
    unpack_string(str).gsub('.', '/')
  end

  def persian_numbers(str)
    if str.is_a? Numeric and not str.is_a? Fixnum
      if str.to_i == str
        unpack_string(str.to_i)
      else
        unpack_float(str)
      end
    else
      str ? unpack_string(str) : ''
    end
  end

  def persian_date(date)
    date ? persian_numbers(JalaliDate.new(date).format("%A %e %b %Y - %H:%M")) : ''
  end

  def persian_date_month(date)
    date ? persian_numbers(JalaliDate.new(date).format("%b %Y")) : ''
  end

  def persian_date_bare(date)
    date ? persian_numbers(JalaliDate.new(date).format("%Y/%m/%d")) : ''
  end

  def persian_days_of_week(i=nil)
    days = [
      'شنبه',
      'یکشنبه',
      'دوشنبه',
      'سه‌شنبه',
      'چهارشنبه',
      'پنجشنبه',
      'جمعه',
    ]
    i ? days[i] : days
  end

  def to_hours(hs)
    hours = hs.floor
    minutes = ((hs - hours)*60).floor
    "#{hours}:"+(minutes < 10 ? "0#{minutes}" : "#{minutes}")
  end

  def persian_months
    {
      'فروردین'   =>  1,
      'اردیبهشت'  =>  2,
      'خرداد'     =>  3,
      'تیر'       =>  4,
      'مرداد'     =>  5,
      'شهریور'    =>  6,
      'مهر'       =>  7,
      'آبان'      =>  8,
      'آذر'       =>  9,
      'دی'        => 10,
      'بهمن'      => 11,
      'اسفند'     => 12 
    }
  end

  def persian_days
    (1..31).to_a.map{|i| {persian_numbers(i.to_s) => i.to_s}}.reduce({}, :merge)
  end

  def persian_years
    today = JalaliDate.today
    y = today.year
    (y-1..y+1).map{|y2| { persian_numbers(y2.to_s) => y2.to_s} }.reduce({}, :merge)
    # { persian_numbers(y.to_s) => y.to_s, persian_numbers((y+1).to_s) => (y+1).to_s}
    # if today.month < 7
    #   { persian_numbers(y.to_s) => y.to_s}
    # else
    #   { persian_numbers(y.to_s) => y.to_s, persian_numbers((y+1).to_s) => (y+1).to_s}
    # end
  end

  def flash_class(level)
    case level
    when :notice then "alert alert-info"
    when :success then "alert alert-success"
    when :error then "alert alert-danger"
    when :alert then "alert alert-warning"
    end
  end

  def title(page_title)
    content_for :title, "مدیر مدرسه :‌ "+page_title.to_s
  end

  def score_state_on_exam(mark, avg, max, min)
    if avg.nil?
      return "<s>بدون نمره</s>"
    else
      if mark.nil?
        return '<b class="text-danger">غایب</b>'
      end
      if mark > avg
        if mark - avg >= (max - avg)/2
          return '<b class="text-success">عالی</b>'
        else
          return '<b class="text-primary">خوب</b>' 
        end
      else
        if avg - mark <= (avg - min)/2
          return '<b class="text-warning">متوسط</b>' 
        else
          return '<b class="text-danger">ضعیف</b>'
        end
      end
    end
  end

  def there_is_no(key)
    I18n.t(key)+I18n.t('there_is_no')
  end

  def issuance_states
    {
      'همه‌ی دروس' => 0,
      'یک درس' => 1,
      'دو درس' => 2,
      'سه درس' => 3
    }
  end

  def round_mark(mark)
    (mark*4).round/4.0
  end

  def poll_types
    {
      0 => "فقط دانش‌آموزان",
      1 => "فقط اولیا",
      2 => "همه‌ی کاربران"
    }
  end

  def poll_type(type)
    poll_types[type || 0]
  end

  def poll_states
    {
      true => "نتایج عمومی",
      false => "نتایج مخفی"
    }
  end

  def poll_state(state)
    poll_states[state || false]
  end

  def seconds_to_text(seconds)
    if seconds < 0
      text = 'کمتر از یک دقیقه'
    else
      text = ''
      text += "#{seconds/3600} ساعت و " if seconds/3600 > 0
      text += "#{seconds/60} دقیقه و "
      text += "#{seconds%60} ثانیه"
    end
    return persian_numbers text
  end
end
