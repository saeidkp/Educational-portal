module AdvisoriesHelper
end
