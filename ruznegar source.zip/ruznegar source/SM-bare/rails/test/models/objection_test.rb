require 'test_helper'

class ObjectionTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
