require 'test_helper'

class ReportPointTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
