require 'test_helper'

class ClassTableTimeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
