require 'test_helper'

class ReportCourseTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
