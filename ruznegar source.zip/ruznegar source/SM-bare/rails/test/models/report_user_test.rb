require 'test_helper'

class ReportUserTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
