require 'test_helper'

class TopicWeeklyTableTimeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
