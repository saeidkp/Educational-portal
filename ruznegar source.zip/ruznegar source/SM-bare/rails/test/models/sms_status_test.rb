require 'test_helper'

class SmsStatusTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
