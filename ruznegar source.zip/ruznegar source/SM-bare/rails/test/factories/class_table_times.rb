# Read about factories at https://github.com/thoughtbot/factory_girl

FactoryGirl.define do
  factory :class_table_time do
  end
end
