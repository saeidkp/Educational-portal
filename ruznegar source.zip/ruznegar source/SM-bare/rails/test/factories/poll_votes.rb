# Read about factories at https://github.com/thoughtbot/factory_girl

FactoryGirl.define do
  factory :poll_vote do
    user nil
    poll nil
    poll_option nil
  end
end
