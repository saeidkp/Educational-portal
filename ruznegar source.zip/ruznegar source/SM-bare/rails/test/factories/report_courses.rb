# Read about factories at https://github.com/thoughtbot/factory_girl

FactoryGirl.define do
  factory :report_course do
    multiplier 1
    exam_quiz_part 1
    exam_homework_part 1
  end
end
