# Read about factories at https://github.com/thoughtbot/factory_girl

FactoryGirl.define do
  factory :report_user do
    average 1.5
  end
end
