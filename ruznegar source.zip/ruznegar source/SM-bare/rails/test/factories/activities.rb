# Read about factories at https://github.com/thoughtbot/factory_girl

FactoryGirl.define do
  factory :activity do
    datetime "2014-04-25 23:21:32"
    integer ""
    belongs_to ""
  end
end
