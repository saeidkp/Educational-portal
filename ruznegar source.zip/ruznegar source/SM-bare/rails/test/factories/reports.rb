# Read about factories at https://github.com/thoughtbot/factory_girl

FactoryGirl.define do
  factory :report do
    name "MyString"
    start_date "2014-03-28"
    end_date "2014-03-28"
    max_grade 1
    ranking false
    objection false
    objection_limit 1
    objection_courses 1
  end
end
