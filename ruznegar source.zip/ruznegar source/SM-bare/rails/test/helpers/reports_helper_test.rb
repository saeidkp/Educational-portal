require 'test_helper'

class ReportsHelperTest < ActionView::TestCase
end
