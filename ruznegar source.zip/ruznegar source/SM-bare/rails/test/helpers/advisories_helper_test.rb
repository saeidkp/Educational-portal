require 'test_helper'

class AdvisoriesHelperTest < ActionView::TestCase
end
