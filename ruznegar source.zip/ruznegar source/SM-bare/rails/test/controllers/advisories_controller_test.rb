require 'test_helper'

class AdvisoriesControllerTest < ActionController::TestCase
  setup do
    @advisory = advisories(:one)
  end

  test "should get index" do
    get :index
    assert_response :success
    assert_not_nil assigns(:advisories)
  end

  test "should get new" do
    get :new
    assert_response :success
  end

  test "should create advisory" do
    assert_difference('Advisory.count') do
      post :create, advisory: {  }
    end

    assert_redirected_to advisory_path(assigns(:advisory))
  end

  test "should show advisory" do
    get :show, id: @advisory
    assert_response :success
  end

  test "should get edit" do
    get :edit, id: @advisory
    assert_response :success
  end

  test "should update advisory" do
    patch :update, id: @advisory, advisory: {  }
    assert_redirected_to advisory_path(assigns(:advisory))
  end

  test "should destroy advisory" do
    assert_difference('Advisory.count', -1) do
      delete :destroy, id: @advisory
    end

    assert_redirected_to advisories_path
  end
end
