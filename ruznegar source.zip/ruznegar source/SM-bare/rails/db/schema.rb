# encoding: UTF-8
# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# Note that this schema.rb definition is the authoritative source for your
# database schema. If you need to create the application database on another
# system, you should be using db:schema:load, not running all the migrations
# from scratch. The latter is a flawed and unsustainable approach (the more migrations
# you'll amass, the slower it'll run and the greater likelihood for issues).
#
# It's strongly recommended that you check this file into your version control system.

ActiveRecord::Schema.define(version: 20141010154259) do

  # These are extensions that must be enabled in order to support this database
  enable_extension "plpgsql"

  create_table "activities", force: true do |t|
    t.datetime "time"
    t.integer  "duration"
    t.integer  "user_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "advisories", force: true do |t|
    t.integer  "user_id"
    t.integer  "advisor_id"
    t.date     "date"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.text     "description"
  end

  create_table "class_table_times", force: true do |t|
    t.integer  "day",              default: 0
    t.integer  "hour",             default: 0
    t.boolean  "tak_zang",         default: false
    t.string   "opt_text"
    t.integer  "course_id"
    t.integer  "second_course_id"
    t.integer  "class_table_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "class_tables", force: true do |t|
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "klass_id"
  end

  create_table "courses", force: true do |t|
    t.string   "name"
    t.integer  "teacher_id"
    t.integer  "klass_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "courses_users", force: true do |t|
    t.integer "user_id"
    t.integer "course_id"
  end

  create_table "events", force: true do |t|
    t.string   "title"
    t.date     "date"
    t.boolean  "global"
    t.integer  "school_id"
    t.integer  "group_id"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.boolean  "off",        default: false
  end

  create_table "exams", force: true do |t|
    t.datetime "date"
    t.decimal  "min",        precision: 5, scale: 2
    t.decimal  "max",        precision: 5, scale: 2
    t.decimal  "average",    precision: 5, scale: 2
    t.integer  "exam_type"
    t.integer  "range",                              default: 20
    t.integer  "course_id"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "title",                              default: ""
  end

  add_index "exams", ["course_id"], name: "index_exams_on_course_id", using: :btree

  create_table "groups", force: true do |t|
    t.string   "name"
    t.integer  "advisor_id"
    t.integer  "school_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "klasses", force: true do |t|
    t.string   "name"
    t.integer  "group_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "messages", force: true do |t|
    t.text     "content"
    t.integer  "m_type"
    t.integer  "from_id"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "file_file_name"
    t.string   "file_content_type"
    t.integer  "file_file_size"
    t.datetime "file_updated_at"
    t.boolean  "failed",            default: false
  end

  create_table "messages_users", force: true do |t|
    t.integer "user_id"
    t.integer "message_id"
  end

  create_table "news", force: true do |t|
    t.text     "content"
    t.string   "title"
    t.integer  "n_type"
    t.integer  "school_id"
    t.integer  "writer_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "objections", force: true do |t|
    t.text     "text"
    t.integer  "report_id"
    t.integer  "report_user_id"
    t.integer  "report_course_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "orders", force: true do |t|
    t.string   "refId"
    t.integer  "amount"
    t.time     "acceptance"
    t.boolean  "completed",  default: false
    t.integer  "user_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "points", force: true do |t|
    t.integer  "exam_id"
    t.integer  "user_id"
    t.decimal  "mark",       precision: 5, scale: 2
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "rank"
  end

  create_table "poll_options", force: true do |t|
    t.integer  "votes",      default: 0
    t.string   "name"
    t.integer  "poll_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "poll_votes", force: true do |t|
    t.integer  "user_id"
    t.integer  "poll_id"
    t.integer  "poll_option_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  add_index "poll_votes", ["poll_id"], name: "index_poll_votes_on_poll_id", using: :btree
  add_index "poll_votes", ["poll_option_id"], name: "index_poll_votes_on_poll_option_id", using: :btree
  add_index "poll_votes", ["user_id"], name: "index_poll_votes_on_user_id", using: :btree

  create_table "polls", force: true do |t|
    t.string   "title"
    t.date     "end_date"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "school_id"
    t.integer  "group_id"
    t.integer  "poll_type"
    t.boolean  "visible"
  end

  create_table "readings", force: true do |t|
    t.date     "date"
    t.string   "start"
    t.string   "content"
    t.integer  "duration"
    t.integer  "user_id"
    t.integer  "course_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "report_courses", force: true do |t|
    t.integer  "multiplier",                                 default: 1
    t.integer  "exam_quiz_part",                             default: 0
    t.integer  "exam_homework_part",                         default: 0
    t.decimal  "average",            precision: 5, scale: 2, default: 0.0
    t.decimal  "max",                precision: 5, scale: 2, default: 0.0
    t.decimal  "min",                precision: 5, scale: 2, default: 0.0
    t.string   "course_name"
    t.integer  "report_id"
    t.integer  "course_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "report_points", force: true do |t|
    t.decimal  "mark",             precision: 5, scale: 2
    t.decimal  "bare_point",       precision: 5, scale: 2
    t.integer  "rank"
    t.integer  "user_id"
    t.integer  "report_course_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "report_users", force: true do |t|
    t.decimal  "average",    precision: 5, scale: 2
    t.integer  "rank"
    t.integer  "user_id"
    t.integer  "report_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "reports", force: true do |t|
    t.string   "name",              default: "کارنامه"
    t.date     "start_date"
    t.date     "end_date"
    t.integer  "max_grade",         default: 20
    t.boolean  "ranking",           default: false
    t.boolean  "objection",         default: false
    t.integer  "objection_limit",   default: 0
    t.integer  "objection_courses", default: 0
    t.boolean  "published",         default: false
    t.integer  "klass_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "schools", force: true do |t|
    t.string   "name"
    t.integer  "admin_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "sessions", force: true do |t|
    t.string   "session_id", null: false
    t.text     "data"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  add_index "sessions", ["session_id"], name: "index_sessions_on_session_id", unique: true, using: :btree
  add_index "sessions", ["updated_at"], name: "index_sessions_on_updated_at", using: :btree

  create_table "settings", force: true do |t|
    t.integer  "sms_price"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.boolean  "only_super_admin", default: false
  end

  create_table "sms_statuses", force: true do |t|
    t.string   "deliver"
    t.integer  "message_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "topic_table_times", force: true do |t|
    t.integer  "minutes"
    t.integer  "time_type",      default: 0
    t.integer  "topic_table_id"
    t.integer  "course_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "topic_tables", force: true do |t|
    t.integer "topic_id"
    t.boolean "is_default", default: false
  end

  create_table "topic_weekly_table_times", force: true do |t|
    t.integer  "dow",                                     default: 0
    t.decimal  "hours",           precision: 5, scale: 2, default: 4.0
    t.integer  "topic_weekly_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "topic_weekly_tables", force: true do |t|
    t.integer  "topic_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "topics", force: true do |t|
    t.string   "name"
    t.integer  "klass_id"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "weekly_table_id"
  end

  create_table "users", force: true do |t|
    t.string   "email",                                          default: ""
    t.string   "encrypted_password",                             default: "",    null: false
    t.string   "username",                                       default: "",    null: false
    t.string   "name",                                           default: "",    null: false
    t.string   "home_phone",                                     default: ""
    t.string   "self_phone",                                     default: ""
    t.decimal  "last_average",           precision: 4, scale: 2
    t.boolean  "has_message",                                    default: false
    t.datetime "last_check_message"
    t.integer  "rank"
    t.date     "birthday"
    t.string   "address",                                        default: ""
    t.string   "address2",                                       default: ""
    t.string   "father_name",                                    default: ""
    t.string   "mother_name",                                    default: ""
    t.string   "father_phone",                                   default: ""
    t.string   "mother_phone",                                   default: ""
    t.string   "father_email",                                   default: ""
    t.string   "mother_email",                                   default: ""
    t.string   "father_work",                                    default: ""
    t.string   "mother_work",                                    default: ""
    t.string   "father_work_name",                               default: ""
    t.string   "mother_work_name",                               default: ""
    t.integer  "user_type",                                      default: 0,     null: false
    t.string   "reset_password_token"
    t.datetime "reset_password_sent_at"
    t.datetime "remember_created_at"
    t.integer  "sign_in_count",                                  default: 0
    t.datetime "current_sign_in_at"
    t.datetime "last_sign_in_at"
    t.string   "current_sign_in_ip"
    t.string   "last_sign_in_ip"
    t.integer  "failed_attempts",                                default: 0
    t.string   "unlock_token"
    t.datetime "locked_at"
    t.integer  "school_id"
    t.integer  "group_id"
    t.integer  "klass_id"
    t.integer  "topic_id"
    t.integer  "topic_table_id"
    t.integer  "parent_of_id"
    t.integer  "parent_id"
    t.boolean  "username_changable",                             default: true
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "avatar_file_name"
    t.string   "avatar_content_type"
    t.integer  "avatar_file_size"
    t.datetime "avatar_updated_at"
    t.integer  "balance",                                        default: 0
    t.boolean  "super_admin",                                    default: false
    t.datetime "last_activity"
    t.boolean  "is_active",                                      default: true
    t.text     "time_table"
  end

  add_index "users", ["reset_password_token"], name: "index_users_on_reset_password_token", unique: true, using: :btree
  add_index "users", ["unlock_token"], name: "index_users_on_unlock_token", unique: true, using: :btree
  add_index "users", ["username"], name: "index_users_on_username", unique: true, using: :btree

end
