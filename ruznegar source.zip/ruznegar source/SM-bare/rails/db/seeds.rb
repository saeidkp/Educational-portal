# Add production seed
User.type_admins.create name: "ادمین", username: 'admin', password: 'password', super_admin: true
User.type_admins.create name: "معاون ادمین", username: 'admin2', password: 'password'
Settings.create sms_price: 90
case Rails.env
when 'production'
when 'development'
  def rndU; (0..10).map{ (48+rand(10)).chr }.join; end

  ActiveRecord::Base.transaction do
    School.create (1..2).map{|i| {name: "مدرسه‌ی #{i}"} }
  end
  schools = School.all.to_a

  ActiveRecord::Base.transaction do
    User.type_teachers.create schools.map{ |school|
      (1..5).map{|i| {name: "دبیر #{i} #{school.name}", username: "teacher#{i}#{school.id}", password: "teacher#{i}#{school.id}", school_id: school.id} }
    }.flatten
  end

  ActiveRecord::Base.transaction do
    Klass.create schools.map{|school|
      groups = school.groups
      groups.map{|group|
        (rand(2)+1).times.map{|i|
          {name: "کلاس #{school.id}#{group.id}#{i}", group_id: group.id}
        }
      }
    }
  end

  ActiveRecord::Base.transaction do
    Course.create schools.map{|school|
      groups = school.groups
      tids = school.teacher_ids
      groups.map{|group|
        (1..(rand(3)+3)).map{|i|
          group.klasses.map{|klass|
            { klass_id: klass.id, name: "درس #{i} کلاس #{klass.name}", teacher_id: tids.sample }
          }
        }.flatten
      }.flatten
    }.flatten
  end

  ActiveRecord::Base.transaction do
    Topic.create schools.map{|school|
      school.groups.map{|group|
        (1+rand(2)).times.map{|i|
          group.klasses.map{|klass|
            { klass_id: klass.id, name: "استارتژی #{i} کلاس #{klass.name}" }
          }
        }.flatten
      }.flatten
    }.flatten
  end

  ActiveRecord::Base.transaction do
    topics = Topic.all
    TopicTable.create topics.map{|topic|
      [{ topic_id: topic.id }]*(1+rand(2))
    }.flatten
  end

  ActiveRecord::Base.transaction do
    tables = TopicTable.all
    TopicTableTime.create tables.map{|table|
      course_ids = table.topic.klass.course_ids
      if table.is_default
        course_ids.map{|course|
          {minutes: (30+rand(7)*10), course_id: course, time_type: APP_CONFIG['time_type'].values.sample, topic_table_id: table.id}
        }
      else
        course_ids.sample((1..course_ids.count).to_a.sample).map{|course|
          {minutes: (30+rand(7)*10), course_id: course, time_type: APP_CONFIG['time_type'].values.sample, topic_table_id: table.id}
        }
      end
    }.flatten
  end

  ActiveRecord::Base.transaction do
    User.type_students.create schools.map{|school|
      klasses = Klass.includes(:topics).where(group_id: school.group_ids)
      topics = klasses.collect(&:topics).flatten
      (1..60).map{|i|
        klass = klasses.sample
        topic = klass.topics.sample
        username = rndU
        _ret = {
          name: "دانش‌آموز #{i} #{klass.name}",
          username: username,
          email: Faker::Internet.email,
          password: username[-4..-1],
          group_id: klass.group_id,
          klass_id: klass.id,
          topic_id: topic.id,
          course_ids: klass.course_ids.sample(rand(2)+2),
          school_id: school.id,
          father_name: "پدر دانش‌آموز #{i} #{klass.name}",
          mother_name: "مادر دانش‌آموز #{i} #{klass.name}",
          father_phone: "09#{(1..9).map{ rand(10) }.join('')}",
          mother_phone: "09#{(1..9).map{ rand(10) }.join('')}",
          self_phone: "09#{(1..9).map{ rand(10) }.join('')}",
          home_phone: "09#{(1..9).map{ rand(10) }.join('')}",
          address: "خیابان سوم",
          father_work_name: "آزاد",
          mother_work_name: "آزاد",
          father_work: "خیابان چهارم",
          mother_work: "خیابان هفتم",
          father_email: Faker::Internet.email,
          mother_email: Faker::Internet.email,
          birthday: Date.today-(15+rand(4)).years+rand(365).days
        }
        if (0..5).to_a.sample == 3 and topic.tables.count > 1
          _ret[:topic_table_id] = topic.tables.reject{|t| t.is_default}.sample.id
        end
        _ret
      }.flatten
    }.flatten
  end

  ActiveRecord::Base.transaction do
    courses = Course.all.entries
    courses.each{|course|
      Exam.create({
        date: DateTime.now+150.days-(rand(300)).days,
        users: course.users,
        course_id: course.id,
        exam_type: APP_CONFIG['exam_type'].values.sample,
        range: [10, 10, 20, 20, 20, 20, 20, 100, 100].sample
      })
    }
  end

  ActiveRecord::Base.transaction do
    exams = Exam.includes(:points).all.entries
    exams.each{|exam|
      if exam.date.past?
        range = exam.range
        exam.points.each{|p| p.update_attributes mark: 0.25*range+range*rand(15)/20.0}
      end
    }
  end

  ActiveRecord::Base.transaction do
    klasses = Klass.all
    klasses.each do |klass|
      objection = rand(4) == 0
      attributes = {
        name: "کارنامه #{klass.name}",
        user_ids: klass.user_ids,
        start_date: (100+rand(100)).days.ago.to_date,
        end_date: rand(20).days.ago.to_date,
        ranking: rand(3) == 2,
        objection: objection,
        published: rand(4) == 0,
        max_grade: [10, 10, 20, 20, 20, 20, 20, 100, 100].sample
      }
      if objection
        attributes[:objection_limit] = 10+rand(20)
        attributes[:objection_courses] = rand(4)
      end
      report = klass.reports.create(attributes)
      klass.courses.each do |course|
        exam_quiz_part = rand(report.max_grade - report.max_grade/2)
        exam_homework_part = if report.max_grade - report.max_grade/2 - exam_quiz_part > 0
          rand(report.max_grade - report.max_grade/2 - exam_quiz_part)
        else
          0
        end
        report.report_courses.create({
          course_id: course.id, multiplier: 1+rand(4), exam_quiz_part: exam_quiz_part, exam_homework_part: exam_homework_part
        })
      end
      report.report_courses.each do |report_course|
        report.report_users.each do |report_user|
          report_course.points.create user_id: report_user.user_id, bare_point: (report.max_grade/3.0+rand(report.max_grade*2/3))
        end
      end
      report.regenerate_points
    end
  end

  news_content = "لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است. چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است و برای شرایط فعلی تکنولوژی مورد نیاز و کاربردهای متنوع با هدف بهبود ابزارهای کاربردی می باشد. کتابهای زیادی در شصت و سه درصد گذشته، حال و آینده شناخت فراوان جامعه و متخصصان را می طلبد تا با نرم افزارها شناخت بیستری را برای طراحان رایانه ای و فرهنگ پیشرو در زبان فارسی ایجاد کرد. در این صورت می توان امید داشت که تمام و دشواری موجود در ارائه راهکارها و شرایط سخت تایپ به پایان رسد وزمان مورد نیاز شامل حروفچینی دستاوردهای اصلی و جوابگوی سوالات پیوسته اهل دنیای موجود طراحی اساسا مورد استفاده قرار گیرد.

  لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است. چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است و برای شرایط فعلی تکنولوژی مورد نیاز و کاربردهای متنوع با هدف بهبود ابزارهای کاربردی می باشد. کتابهای زیادی در شصت و سه درصد گذشته، حال و آینده شناخت فراوان جامعه و متخصصان را می طلبد تا با نرم افزارها شناخت بیستری را برای طراحان رایانه ای و فرهنگ پیشرو در زبان فارسی ایجاد کرد. در این صورت می توان امید داشت که تمام و دشواری موجود در ارائه راهکارها و شرایط سخت تایپ به پایان رسد وزمان مورد نیاز شامل حروفچینی دستاوردهای اصلی و جوابگوی سوالات پیوسته اهل دنیای موجود طراحی اساسا مورد استفاده قرار گیرد."

  ActiveRecord::Base.transaction do
    News.create schools.map{|school|
      user_ids = User.where(user_type: [APP_CONFIG['user_types']['advisor'], APP_CONFIG['user_types']['manager']], school_id: school.id).pluck(:id)
      {title: "خبر", content: news_content, school_id: school.id, writer_id: user_ids.sample}
    }
  end
end
