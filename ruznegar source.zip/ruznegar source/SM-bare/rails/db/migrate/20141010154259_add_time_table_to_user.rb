class AddTimeTableToUser < ActiveRecord::Migration
  def change
    change_table :users do |t|
      t.text :time_table
    end
  end
end
