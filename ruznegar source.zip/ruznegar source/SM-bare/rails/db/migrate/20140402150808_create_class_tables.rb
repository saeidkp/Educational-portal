class CreateClassTables < ActiveRecord::Migration
  def change
    create_table :class_tables do |t|
      t.timestamps
      t.belongs_to :klass
    end
  end
end
