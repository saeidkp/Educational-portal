class AddRankToPoints < ActiveRecord::Migration
  def change
    change_table :points do |t|
      t.integer :rank, default: nil, allow_nil: true
    end
  end
end
