class CreatePollOptions < ActiveRecord::Migration
  def change
    create_table :poll_options do |t|
      t.integer :votes, default: 0
      t.string :name
      t.belongs_to :poll

      t.timestamps
    end
  end
end
