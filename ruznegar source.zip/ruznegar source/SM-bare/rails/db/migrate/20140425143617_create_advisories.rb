class CreateAdvisories < ActiveRecord::Migration
  def change
    create_table :advisories do |t|
      t.belongs_to :user
      t.belongs_to :advisor
      t.date :date

      t.timestamps
    end
  end
end
