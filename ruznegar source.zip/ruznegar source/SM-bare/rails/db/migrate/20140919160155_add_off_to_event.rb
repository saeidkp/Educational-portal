class AddOffToEvent < ActiveRecord::Migration
  def change
    change_table :events do |t|
      t.boolean :off, default: false
    end
  end
end
