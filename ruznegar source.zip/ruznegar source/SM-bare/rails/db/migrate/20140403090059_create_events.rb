class CreateEvents < ActiveRecord::Migration
  def change
    create_table :events do |t|
      t.string :title
      t.date :date
      t.boolean :global
      t.belongs_to :school
      t.belongs_to :group
      t.timestamps
    end
  end
end
