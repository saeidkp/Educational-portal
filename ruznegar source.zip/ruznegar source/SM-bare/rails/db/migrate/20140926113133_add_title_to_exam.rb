class AddTitleToExam < ActiveRecord::Migration
  def change
    change_table :exams do |t|
      t.string :title, default: ''
    end
  end
end
