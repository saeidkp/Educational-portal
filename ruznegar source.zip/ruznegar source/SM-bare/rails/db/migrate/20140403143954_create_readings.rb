class CreateReadings < ActiveRecord::Migration
  def change
    create_table :readings do |t|
      t.date :date
      t.string :start
      t.string :content
      t.integer :duration
      t.belongs_to :user
      t.belongs_to :course
      t.timestamps
    end
  end
end
