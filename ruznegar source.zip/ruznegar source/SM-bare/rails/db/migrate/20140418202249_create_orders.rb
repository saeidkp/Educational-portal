class CreateOrders < ActiveRecord::Migration
  def change
    create_table :orders do |t|
      t.string :refId
      t.integer :amount
      t.time :acceptance
      t.boolean :completed, default: false

      t.belongs_to :user

      t.timestamps
    end
  end
end
