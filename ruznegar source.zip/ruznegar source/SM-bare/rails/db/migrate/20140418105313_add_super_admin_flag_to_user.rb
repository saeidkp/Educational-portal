class AddSuperAdminFlagToUser < ActiveRecord::Migration
  def change
    change_table :users do |t|
      t.boolean :super_admin, default: false, allow_nil: false
    end
  end
end
