class AddPollToSchool < ActiveRecord::Migration
  def change
    change_table :polls do |t|
      t.belongs_to :school
      t.belongs_to :group
      t.integer :poll_type
      t.boolean :visible
    end
  end
end
