class CreateTopicWeeklyTableTimes < ActiveRecord::Migration
  def change
    create_table :topic_weekly_table_times do |t|
      t.integer :dow, default: 0, allow_nil: false
      t.decimal :hours, precision: 5, scale: 2, default: 4, allow_nil: false
      t.integer :topic_weekly_id
      t.timestamps
    end
  end
end
