class AddActivityToUser < ActiveRecord::Migration
  def change
    change_table :users do |t|
      t.timestamp :last_activity
    end
  end
end
