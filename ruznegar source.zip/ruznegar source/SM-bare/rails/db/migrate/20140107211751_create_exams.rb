class CreateExams < ActiveRecord::Migration
  def change
    create_table :exams do |t|
      t.datetime :date
      t.decimal :min, precision: 5, scale: 2
      t.decimal :max, precision: 5, scale: 2
      t.decimal :average, precision: 5, scale: 2
      t.integer :exam_type
      t.integer :range, default: 20, allow_nil: false

      t.belongs_to :course

      t.timestamps
    end

    add_index :exams, :course_id
  end
end
