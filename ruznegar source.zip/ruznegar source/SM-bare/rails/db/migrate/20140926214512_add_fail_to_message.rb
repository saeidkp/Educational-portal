class AddFailToMessage < ActiveRecord::Migration
  def change
    change_table :messages do |t|
      t.boolean :failed, default: false
    end
  end
end
