class CreateSmsStatuses < ActiveRecord::Migration
  def change
    create_table :sms_statuses do |t|
      t.string :deliver, allow_nil: false
      t.belongs_to :message
      t.timestamps
    end
  end
end
