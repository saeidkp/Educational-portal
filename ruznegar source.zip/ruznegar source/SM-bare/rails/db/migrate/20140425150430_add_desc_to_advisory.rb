class AddDescToAdvisory < ActiveRecord::Migration
  def change
    change_table :advisories do |t|
      t.text :description
    end
  end
end
