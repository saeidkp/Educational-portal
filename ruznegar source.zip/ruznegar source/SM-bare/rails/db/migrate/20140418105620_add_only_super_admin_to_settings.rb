class AddOnlySuperAdminToSettings < ActiveRecord::Migration
  def change
    change_table :settings do |t|
      t.boolean :only_super_admin, default: false, allow_nil: false
    end
  end
end
