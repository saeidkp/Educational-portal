class CreateClassTableTimes < ActiveRecord::Migration
  def change
    create_table :class_table_times do |t|
      t.integer :day, default: 0, allow_nil: false
      t.integer :hour, default: 0, allow_nil: false
      t.boolean :tak_zang, default: false, allow_nil: false
      t.string  :opt_text
      t.belongs_to :course
      t.integer :second_course_id
      t.belongs_to :class_table
      t.timestamps
    end
  end
end
