class CreateReportCourses < ActiveRecord::Migration
  def change
    create_table :report_courses do |t|
      t.integer :multiplier, default: 1
      t.integer :exam_quiz_part, default: 0
      t.integer :exam_homework_part, default: 0

      t.decimal :average, default: 0.0, precision: 5, scale: 2
      t.decimal :max, default: 0.0, precision: 5, scale: 2
      t.decimal :min, default: 0.0, precision: 5, scale: 2

      t.string :course_name

      t.belongs_to :report
      t.belongs_to :course

      t.timestamps
    end
  end
end
