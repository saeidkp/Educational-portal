class AddIsActiveToUser < ActiveRecord::Migration
  def change
    change_table :users do |t|
      t.boolean :is_active, default: true, allow_nil: false
    end
  end
end
