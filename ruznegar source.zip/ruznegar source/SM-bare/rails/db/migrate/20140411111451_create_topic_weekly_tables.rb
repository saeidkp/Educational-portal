class CreateTopicWeeklyTables < ActiveRecord::Migration
  def change
    create_table :topic_weekly_tables do |t|
      t.belongs_to :topic
      t.timestamps
    end
  end
end
