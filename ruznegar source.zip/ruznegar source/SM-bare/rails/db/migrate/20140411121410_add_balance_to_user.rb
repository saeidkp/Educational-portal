class AddBalanceToUser < ActiveRecord::Migration
  def change
    change_table :users do |t|
      t.integer :balance, default: 0, allow_nil: false
    end
  end
end
