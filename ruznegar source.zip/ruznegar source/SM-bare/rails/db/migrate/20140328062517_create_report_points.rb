class CreateReportPoints < ActiveRecord::Migration
  def change
    create_table :report_points do |t|
      t.decimal :mark, precision: 5, scale: 2
      t.decimal :bare_point, precision: 5, scale: 2

      t.integer :rank

      t.belongs_to :user
      t.belongs_to :report_course

      t.timestamps
    end
  end
end
