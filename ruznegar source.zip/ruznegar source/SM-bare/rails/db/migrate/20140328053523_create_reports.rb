class CreateReports < ActiveRecord::Migration
  def change
    create_table :reports do |t|
      t.string :name, default: I18n.t('report')
      t.date :start_date
      t.date :end_date
      t.integer :max_grade, default: 20
      t.boolean :ranking, default: false
      t.boolean :objection, default: false
      t.integer :objection_limit, default: 0
      t.integer :objection_courses, default: 0

      t.boolean :published, default: false

      t.belongs_to :klass

      t.timestamps
    end
  end
end
