class CreateObjections < ActiveRecord::Migration
  def change
    create_table :objections do |t|
      t.text :text
      t.belongs_to :report
      t.belongs_to :report_user
      t.belongs_to :report_course

      t.timestamps
    end
  end
end
