class CreatePollVotes < ActiveRecord::Migration
  def change
    create_table :poll_votes do |t|
      t.belongs_to :user, index: true
      t.belongs_to :poll, index: true
      t.belongs_to :poll_option, index: true

      t.timestamps
    end
  end
end
