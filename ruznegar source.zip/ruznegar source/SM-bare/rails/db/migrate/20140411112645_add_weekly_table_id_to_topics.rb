class AddWeeklyTableIdToTopics < ActiveRecord::Migration
  def change
    change_table :topics do |t|
      t.integer :weekly_table_id
    end
  end
end
