class CreateReportUsers < ActiveRecord::Migration
  def change
    create_table :report_users do |t|
      t.decimal :average, precision: 5, scale: 2
      t.integer :rank

      t.belongs_to :user
      t.belongs_to :report

      t.timestamps
    end
  end
end
