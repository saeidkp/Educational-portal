# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
SchoolManager::Application.config.secret_key_base = '5f54ca42d46137e5cd4d330b21125e3facd1d47a632c2c1d5c53e2d1405580b0eb754658f9556aec5c972b2e02242116e86cf61b4f82481019cc6067cd2d71f1'

# secret = ENV['SECRET_TOKEN']
# if secret.nil? || secret.length < 30
#   puts "Secret token cannot be loaded"
# else
#   SchoolManager::Application.config.secret_key_base = secret
# end
