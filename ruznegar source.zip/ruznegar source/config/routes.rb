SchoolManager::Application.routes.draw do
  resources :topics

  resources :messages, only: [:index, :new, :create, :destroy] do
    get 'sent' => 'messages#index_sent', on: :collection
  end

  resources :klasses, only: [:new, :create, :edit, :update, :destroy]

  resources :news

  resources :schools

  devise_for :users
  resources :users
  resources :courses# do
  #   resources :exams do
  #     patch 'points' => 'exams#points' ,on: :member
  #     get 'points' => 'exams#edit_points' ,on: :member
  #   end
  # end
  get 'me' => 'pages#me'
  post 'me' => 'pages#update_me'
  get 'settings' => 'pages#settings'
  resources :exams do
    patch 'points' => 'exams#points', on: :member
    get 'points' => 'exams#edit_points', on: :member
  end

  get 'time/:id' => 'pages#time'
  post 'time/:id' => 'pages#edit_time'
  delete 'time/:id' => 'pages#destroy_time'
  get 'time' => 'pages#new_time'
  post 'time' => 'pages#create_time'

  get 'table' => 'pages#new_table'
  post 'table' => 'pages#create_table'
  get 'table/:id' => 'pages#edit_table'
  post 'table/:id' => 'pages#update_table'
  delete 'table/:id' => 'pages#destroy_table'
  root "pages#index"
  # root "index#home"
end
