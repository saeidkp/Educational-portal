require 'test_helper'

class SchoolsHelperTest < ActionView::TestCase
end
