require 'test_helper'

class KlassTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
