require 'test_helper'

class TopicTableTimeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
