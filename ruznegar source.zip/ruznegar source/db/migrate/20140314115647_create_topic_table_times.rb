class CreateTopicTableTimes < ActiveRecord::Migration
  def change
    create_table :topic_table_times do |t|
      t.integer :minutes
      t.integer :time_type, default: 0

      t.belongs_to :topic_table
      t.belongs_to :course

      t.timestamps
    end
  end
end
