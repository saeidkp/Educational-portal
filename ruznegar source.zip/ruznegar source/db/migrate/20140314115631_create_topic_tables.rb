class CreateTopicTables < ActiveRecord::Migration
  def change
    create_table :topic_tables do |t|
      t.belongs_to :topic
      t.boolean :is_default, default: false
    end
  end
end
