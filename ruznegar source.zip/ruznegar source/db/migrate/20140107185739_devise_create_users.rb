class DeviseCreateUsers < ActiveRecord::Migration
  def change
    create_table(:users) do |t|
      ## Database authenticatable
      t.string :email,              :null => true,  :default => ""
      t.string :encrypted_password, :null => false, :default => ""

      t.string :username,           :null => false, :default => ""

      t.string :name, :null => false, :default => ""

      t.string :home_phone, :null => true, :default => ""
      t.string :self_phone, :null => true, :default => ""

      t.decimal :last_average, precision: 4, scale: 2

      t.boolean :has_message, default: false
      t.datetime :last_check_message

      t.integer :rank

      t.date :birthday, :null => true

      t.string :address, :null => true, :default => ""

      t.string :father_name, :null => true, :default => ""
      t.string :mother_name, :null => true, :default => ""

      t.string :father_phone, :null => true, :default => ""
      t.string :mother_phone, :null => true, :default => ""

      t.string :father_email, :null => true, :default => ""
      t.string :mother_email, :null => true, :default => ""

      t.string :father_work, :null => true, :default => ""
      t.string :mother_work, :null => true, :default => ""

      t.string :father_work_name, default: ""
      t.string :mother_work_name, default: ""

      t.integer :user_type, null: false, default: 0 # default is guest

      ## Recoverable
      t.string   :reset_password_token
      t.datetime :reset_password_sent_at

      ## Rememberable
      t.datetime :remember_created_at

      ## Trackable
      t.integer  :sign_in_count, :default => 0
      t.datetime :current_sign_in_at
      t.datetime :last_sign_in_at
      t.string   :current_sign_in_ip
      t.string   :last_sign_in_ip

      ## Confirmable
      # t.string   :confirmation_token
      # t.datetime :confirmed_at
      # t.datetime :confirmation_sent_at
      # t.string   :unconfirmed_email # Only if using reconfirmable

      ## Lockable
      t.integer  :failed_attempts, :default => 0 # Only if lock strategy is :failed_attempts
      t.string   :unlock_token # Only if unlock strategy is :email or :both
      t.datetime :locked_at

      ## Token authenticatable
      # t.string :authentication_token
      
      t.belongs_to :school
      t.belongs_to :group
      t.belongs_to :klass
      t.belongs_to :topic
      t.belongs_to :topic_table

      t.integer :parent_of_id
      t.integer :parent_id

      t.boolean :username_changable, default: true

      t.timestamps
    end

    # add_index :users, :email,                :unique => true
    add_index :users, :username,             :unique => true
    add_index :users, :reset_password_token, :unique => true
    # add_index :users, :confirmation_token,   :unique => true
    add_index :users, :unlock_token,         :unique => true
    # add_index :users, :authentication_token, :unique => true
  end
end
