class CreatePoints < ActiveRecord::Migration
  def change
    create_table :points do |t|
      t.belongs_to :exam
      t.belongs_to :user
      t.float :mark, precision: 4, scale: 2
      t.timestamps
    end
  end
end
