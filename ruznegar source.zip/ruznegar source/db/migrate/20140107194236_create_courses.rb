class CreateCourses < ActiveRecord::Migration
  def change
    create_table :courses do |t|
      t.string :name

      t.integer :teacher_id

      t.belongs_to :klass

      t.timestamps
    end

    create_table :courses_users do |t|
      t.belongs_to :user
      t.belongs_to :course
    end
  end
end
