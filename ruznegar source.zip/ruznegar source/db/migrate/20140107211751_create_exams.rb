class CreateExams < ActiveRecord::Migration
  def change
    create_table :exams do |t|
      t.datetime :date
      t.float :min
      t.float :max
      t.float :average
      t.integer :exam_type

      t.belongs_to :course

      t.timestamps
    end

    add_index :exams, :course_id
  end
end
