class CreateMessages < ActiveRecord::Migration
  def change
    create_table :messages do |t|
      t.text :content
      t.integer :m_type
      t.integer :from_id

      t.timestamps
    end

    create_table :messages_users do |t|
      t.belongs_to :user
      t.belongs_to :message
    end
  end
end
